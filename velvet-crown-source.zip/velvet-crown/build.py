"""Build Death at the Velvet Crown.

1. Writes js/secrets.js: locks, hints and the solution, base64-encoded so a
   curious player can't read them by glancing at the source.
2. Bundles index.html, css/ and js/ into a single self-contained dist/index.html
   for GitHub Pages.
"""
import base64, json, os, re

ROOT = os.path.dirname(os.path.abspath(__file__))

SECRET = {
    "locks": {"B": "7294", "C": ["GREYGHOST", "GRAYGHOST", "GRAUENGEIST", "GRAUEGEIST"]},
    "callReply": "Duret: \u201cThe Grey Ghost\u2026 Anton Grauer. I remember that trial. If his child is under this roof, "
                 "I want every locker in the building opened. Give me an hour.\u201d",
    "hints": {
        "B": [
            "Victor\u2019s note says his four oldest friends keep the code. Marco\u2019s first interview tells you who those friends are.",
            "Four old, yellowed cards from Victor\u2019s first deck are hidden around the desk in the crime scene photograph. "
            "Use the magnifier around the edges: the photo frame, the book, the blotter, the ashtray.",
            "Put the four cards in the order of Victor\u2019s heart. Isabella quotes it in her first interview: hearts, spades, "
            "diamonds, clubs. The code is the four card values in that order.",
        ],
        "C": [
            "Page 13 is written in Victor\u2019s card shorthand, and the key is the worn card tucked into the notebook. "
            "Clubs are liars: skip every club.",
            "A heart carries the first thirteen letters: ace is A, two is B, and so on to king, which is M. "
            "A spade carries the last thirteen: ace is N, up to king, which is Z. A diamond is a space between words.",
            "The first word: 7\u2660 is T, 8\u2665 is H, 5\u2665 is E, then a diamond ends the word: THE. "
            "Carry on the same way, then tell Duret the name in the message.",
        ],
        "F": [
            "Start with the camera. Who at the gala is about 1.83 m tall in their shoes, left-handed, and had no witness "
            "between 23:05 and 23:20?",
            "The keycard log says I. VALMONT at 23:11, but check the photographer\u2019s timestamps. Where was Isabella then, "
            "and who had his hands near her clutch that evening?",
            "Follow the decks. Which seal was in Victor\u2019s bin, which table was it issued to, and whose locker holds the "
            "deck Marco actually delivered?",
        ],
    },
    "answers": {
        "B": "The seven of hearts is under the ashtray, the two of spades is tucked into the photo frame, the nine of "
             "diamonds marks a page in the book and the four of clubs peeks out from under the blotter. "
             "The code is <strong>7294</strong>.",
        "C": "Page 13 reads: THE GREY GHOST\u2019S CHILD IS UNDER MY ROOF. Tell Duret <strong>Grey Ghost</strong>.",
    },
    "solution": {"who": "tobias", "how": "cards", "entry": "lifted", "why": "revenge"},
    "ratings": {
        "perfect": ["Master detectives", "Every card on the table, read correctly. Tobias Grey is in custody, and "
                    "Chief Inspector Duret owes you both a very good dinner."],
        "good": ["Sharp-eyed detectives", "You named the killer and most of how he did it. One card slipped past you, "
                 "but the case holds."],
        "who": ["You caught him, just about", "You named the right man, but his lawyer will have fun with the details. "
                "Read what really happened to see what you missed."],
        "wrong": ["The wrong mask", "Tobias Grey walks out into the dawn while someone else answers for his crime. Read "
                  "what really happened, then shuffle up for a rematch some day."],
    },
    "chapters": [
        {"title": "The man behind the mask", "html":
            "<p>Tobias Grey was born Tobias Grauer, the only child of Anton Grauer, the illusionist Monte Verde knew as "
            "the Grey Ghost.</p>"
            "<p>In March 2004, Victor Valmont told a court he had watched Anton switch marked cards into play at the "
            "high-stakes tables. It wasn\u2019t true. The marked cards were real, but the cheat was someone else, and "
            "Victor chose to protect the name of his casino rather than find out who. Anton got six years. He died in "
            "prison in 2009, three months before his release, still saying he had never cheated at cards, only at "
            "magic.</p>"
            "<p>Tobias was eight when his father was sentenced. He grew up in Innsbruck with his mother, learned every one "
            "of his father\u2019s tricks, shortened his name to Grey, and in 2024 took a job dealing cards at the Velvet "
            "Crown. He was patient. He learned the house, its keycards and its habits, and above all Victor\u2019s oldest "
            "ritual: the Last Hand.</p>"
            "<p>The bitter irony is that Victor recognised him. The same hands, the same smile, the same trick with the "
            "ring. On Monday the notary would have made the Velvet Crown, entire, the property of the only child of the "
            "man Victor wronged. Tobias killed him two days before he would have inherited everything.</p>"},
        {"title": "How it was done", "html":
            "<ol>"
            "<li><strong>21:30.</strong> Tobias pockets deck VC-0431 from his own table\u2019s supply and writes it off "
            "as ruined by a spilled drink. Ana Kova\u010d, who served every drink at that table, saw no spill.</li>"
            "<li><strong>21:40 to 21:55, his first break.</strong> With a magician\u2019s tools he opens the pack, paints "
            "the corners of all 52 cards with home-made foxglove extract (the <i>Fingerhut</i> of the dropper bottle) and "
            "reseals the cellophane with a glue pen and heat sealer. Only a second line of glue gives it away.</li>"
            "<li><strong>About 22:50.</strong> At the final table he makes Isabella\u2019s wedding ring vanish into "
            "Nikolai\u2019s champagne. While every eye is on the glass, his left hand lifts the keycard out of her clutch "
            "on the rail.</li>"
            "<li><strong>23:05.</strong> His second break. The staff corridor and the private stairs are 40 seconds "
            "away. He pulls on black gloves and a white Bauta mask, one of sixty handed out to guests.</li>"
            "<li><strong>23:11.</strong> Camera 04 records a masked figure of 1.83 m in a tuxedo, holding a card to the "
            "reader with the left hand. The log says I. VALMONT, but Isabella is on stage in front of three hundred people, "
            "as R\u00e9my\u2019s photographs prove at 23:03, 23:14 and 23:18.</li>"
            "<li><strong>23:11 to 23:14.</strong> Inside, he swaps the sealed deck Marco left on the blotter, VC-0917, "
            "for his poisoned VC-0431 in its identical wrapper, touches nothing else and slips out.</li>"
            "<li><strong>23:20.</strong> Back at the table, out of breath and pink in the face, as Ana noticed.</li>"
            "<li><strong>23:29.</strong> Victor comes up for the Last Hand. He breaks the seal, deals his solitaire and, "
            "as he has for forty years, licks his thumb before every card. Each lick carries a little more poison. He dies "
            "at the desk between 23:40 and midnight.</li>"
            "<li><strong>About 23:35.</strong> Isabella knocks her clutch off the rail. Tobias picks it up and hands it "
            "back with the keycard already inside. At 00:30 she gives it to the police without knowing it was ever "
            "gone.</li>"
            "<li><strong>After midnight.</strong> Nobody may leave once the building is sealed at 00:15, so the untouched "
            "deck VC-0917, the mask, the gloves and the empty bottle are still in locker 21 when the police open it.</li>"
            "</ol>"},
        {"title": "The clues that point to him", "html":
            "<ul>"
            "<li>He had the height: 1.84 m in his shoes, and the camera measured 1.83 m, give or take 2 cm.</li>"
            "<li>He deals left-handed, and the figure on camera 04 holds the card in the left hand.</li>"
            "<li>His break ran from 23:05 to 23:20, exactly when the office was entered, and his terrace alibi has no "
            "witness and no camera.</li>"
            "<li>He had his hands near Isabella\u2019s clutch twice: the ring trick before 23:00 and the pick-up at 23:35.</li>"
            "<li>The wrapper in Victor\u2019s bin carries seal VC-0431, a deck issued to his table and written off because "
            "of a spill nobody else saw.</li>"
            "<li>The real deck, VC-0917, was sealed in his locker, with the Bauta mask, the gloves, the resealing kit "
            "and an empty bottle labelled <i>Fingerhut</i>, German for foxglove.</li>"
            "<li>His father was the Grey Ghost: the photograph in his locker with its German dedication, the Vanishing "
            "Ring, and Victor\u2019s own notebook: \u201cSame hands. Same smile. Even the same trick with the ring.\u201d</li>"
            "</ul>"},
        {"title": "Why it wasn\u2019t the others", "html":
            "<ul>"
            "<li><strong>Isabella Valmont</strong> had the biggest money motive, since the new will would have cut her "
            "down to a villa and an allowance. But she was on stage from 23:00 to 23:25, and the photographer\u2019s "
            "timestamps put her there at 23:03, 23:14 and 23:18. Her keycard was used; she wasn\u2019t. Her secret was "
            "the affair with Nikolai.</li>"
            "<li><strong>Marco Santoro</strong> was stealing from the count, and Victor knew. But he was in the Cage with "
            "Mirela from 23:05 to 23:19, confirmed by camera 02, and at 1.77 m he is too short for the figure on camera.</li>"
            "<li><strong>Dr Leopold Kraus</strong> owed Victor \u20ac380,000 and faced the medical board. But he was "
            "dealt into every hand at the final table, he is 1.71 m, and the poison was a crude plant extract, not his "
            "digoxin tablets.</li>"
            "<li><strong>Nikolai Petrov</strong> wanted the casino and Victor\u2019s wife. But he played every hand from "
            "23:00 to 23:30, and at 1.95 m he could never pass for a 1.83 m figure.</li>"
            "<li><strong>Celeste Moreau</strong> was the red herring. Her height fits, her father was a performer who "
            "died when she was nine, and she wanted out of her contract. But she was singing the duet when the office was "
            "entered, the Grey Ghost\u2019s child was a son, and her father played trumpet in a circus band.</li>"
            "</ul>"},
        {"title": "Epilogue", "html":
            "<p>Tobias Grey made no attempt to deny it once Duret laid the photograph from his locker beside the 2004 "
            "newspaper. He asked her one question: was it true that Victor had meant to leave him the casino? When she "
            "said yes, he didn\u2019t speak again for an hour.</p>"
            "<p>The Velvet Crown stayed dark for a month. When it reopened, its new owner, Isabella Valmont, had hung a "
            "portrait in the lobby: a tall man in a grey tailcoat pulling a ring out of thin air. The brass plaque "
            "beneath it reads: <i>Anton Grauer, the Grey Ghost. He never cheated at cards.</i></p>"
            "<p>Chief Inspector Duret sends her thanks, and her opinion that the two of you have earned a very good "
            "dinner.</p>"},
    ],
}

SCRIPTS = ["art-core", "art-portraits", "art-scene", "art-plan", "art-cctv", "case-meta", "case-a", "case-b",
           "case-c", "secrets", "audio", "app-core", "app-play"]


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def main():
    payload = base64.b64encode(json.dumps(SECRET, ensure_ascii=True).encode("ascii")).decode("ascii")
    with open(os.path.join(ROOT, "js", "secrets.js"), "w", encoding="utf-8") as f:
        f.write("/* Locks, hints and the solution. Encoded so nobody spoils the ending by accident. */\n")
        f.write("window.VC_SECRET = '" + payload + "';\n")

    html = read("index.html")
    for css in ("base", "docs"):
        tag = '<link rel="stylesheet" href="css/%s.css">' % css
        assert tag in html, tag
        html = html.replace(tag, "<style>\n" + read("css/%s.css" % css) + "\n</style>")
    for js in SCRIPTS:
        tag = '<script src="js/%s.js"></script>' % js
        assert tag in html, tag
        code = read("js/%s.js" % js).replace("</script", "<\\/script")
        html = html.replace(tag, "<script>\n" + code + "\n</script>")
    assert not re.search(r'src="js/|href="css/', html)
    os.makedirs(os.path.join(ROOT, "dist"), exist_ok=True)
    with open(os.path.join(ROOT, "dist", "index.html"), "w", encoding="utf-8") as f:
        f.write(html)
    print("dist/index.html: %.0f KB" % (len(html.encode("utf-8")) / 1024))


if __name__ == "__main__":
    main()

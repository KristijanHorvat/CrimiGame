/* Velvet Crown: the case. Envelopes, suspects and the accusation form. */
window.CASE = (function () {
  'use strict';
  var Art = window.Art;
  var C = { evidence: [] };

  C.envelopes = [
    { id: 'A', title: 'The night of the masquerade', line: 'The first file from Chief Inspector Duret.' },
    { id: 'B', title: 'Victor\u2019s safe', line: 'Behind the painting in the Crown Office. The code died with him.', lock: 'safe' },
    { id: 'C', title: 'Lab results and lockers', line: 'Duret sends these as soon as you can read her page 13 of Victor\u2019s notebook.', lock: 'call' }
  ];

  C.suspects = [
    { id: 'isabella', name: 'Isabella Valmont', role: 'Victor\u2019s wife', age: 41, height: '1.76 m', mask: 'Silver butterfly', keycard: 'Yes',
      about: 'Married Victor in 2016. Former headline singer of the Velvet Crown revue. Sole heir under his current will, written in 2017.' },
    { id: 'marco', name: 'Marco Santoro', role: 'Floor manager', age: 55, height: '1.77 m', mask: 'Black half-mask (staff)', keycard: 'Yes',
      about: 'Victor\u2019s right hand since 2001. Runs the gaming floor and the nightly count. Delivers the fresh deck for Victor\u2019s Last Hand every evening.' },
    { id: 'kraus', name: 'Dr Leopold Kraus', role: 'Victor\u2019s physician', age: 63, height: '1.71 m', mask: 'Ivory plague doctor', keycard: 'No',
      about: 'Victor\u2019s doctor and friend of forty years. An enthusiastic, unlucky gambler. Played the final table tonight. Left his medical bag in the cloakroom.' },
    { id: 'nikolai', name: 'Nikolai Petrov', role: 'Rival casino owner', age: 54, height: '1.95 m', mask: 'Gilded lion', keycard: 'No',
      about: 'Owner of the Aurora Palace across the bay. Has offered to buy the Velvet Crown three times. Played the final table tonight.' },
    { id: 'celeste', name: 'Celeste Moreau', role: 'Resident jazz singer', age: 31, height: '1.82 m', mask: 'Black feathers', keycard: 'No',
      about: 'Three years into a six-year contract. Headlined the gala and sang a surprise duet with Mrs Valmont.' },
    { id: 'tobias', name: 'Tobias Grey', role: 'Dealer, Salon Priv\u00e9', age: 30, height: '1.84 m', mask: 'Black half-mask (staff)', keycard: 'No',
      about: 'Dealer at the Velvet Crown since 2024. Amateur card magician, popular with guests and staff. Deals left-handed. Dealt the final table tonight.' }
  ];

  C.witnesses = {
    ana: { name: 'Ana Kova\u010d', role: 'Relief dealer' },
    mirela: { name: 'Mirela Begi\u0107', role: 'Cashier, the Cage' },
    luka: { name: 'Luka Petri\u0107', role: 'Bartender, Le Tr\u00e8fle' }
  };

  C.accusation = [
    { id: 'who', q: 'Who killed Victor Valmont?', type: 'suspect' },
    { id: 'how', q: 'How did the poison reach him?', options: [
      { id: 'cognac', t: 'It was in the cognac decanter' },
      { id: 'cigar', t: 'It was on his cigar' },
      { id: 'cards', t: 'It was on the corners of a swapped, resealed deck of cards' },
      { id: 'tablets', t: 'His heart tablets were switched' },
      { id: 'champagne', t: 'It was in the midnight champagne' }] },
    { id: 'entry', q: 'How did the killer get into the office at 23:11?', options: [
      { id: 'victor', t: 'Victor let them in' },
      { id: 'marco', t: 'With Marco\u2019s keycard' },
      { id: 'lifted', t: 'With Isabella\u2019s keycard, lifted from her clutch without her knowing' },
      { id: 'lent', t: 'Isabella handed her keycard to an accomplice' }] },
    { id: 'why', q: 'Why?', options: [
      { id: 'will', t: 'To inherit the casino before the new will was signed' },
      { id: 'revenge', t: 'Revenge for a father sent to prison on Victor\u2019s false word' },
      { id: 'debt', t: 'To wipe out a \u20ac380,000 debt' },
      { id: 'skim', t: 'To hide money skimmed from the count' },
      { id: 'takeover', t: 'To force the sale of the Velvet Crown' },
      { id: 'contract', t: 'To escape a three-year contract' }] }
  ];

  C.esc = function (t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  };
  C.suspect = function (id) { return C.suspects.filter(function (s) { return s.id === id; })[0]; };
  C.add = function (ev) { C.evidence.push(ev); };

  /* Transcript block for an interview. */
  C.statement = function (doc, id, html) {
    var s = C.suspect(id), w = C.witnesses[id];
    var who = s ? Art.portrait(id, 'portrait portrait-mini') :
      '<span class="badge-initials" aria-hidden="true">' + w.name.split(' ').map(function (p) { return p[0]; }).join('') + '</span>';
    var p = s || w;
    return '<section class="stmt" id="' + doc + '-' + id + '"><header class="stmt-who">' + who +
      '<div><h4>' + p.name + '</h4><p>' + p.role + '</p></div></header><div class="stmt-body">' + html + '</div></section>';
  };
  C.jump = function (doc, ids) {
    return '<nav class="jump" aria-label="Jump to a statement">' + ids.map(function (id) {
      var p = C.suspect(id) || C.witnesses[id];
      return '<button type="button" class="chip" data-jump="' + doc + '-' + id + '">' + p.name.replace('Dr ', '').split(' ')[0] + '</button>';
    }).join('') + '</nav>';
  };
  C.head = function (left, right) {
    return '<header class="rep-head"><span>' + left + '</span><span>' + right + '</span></header>';
  };

  return C;
})();

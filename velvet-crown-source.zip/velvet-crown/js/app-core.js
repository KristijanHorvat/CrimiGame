/* Velvet Crown: game engine, part 1. */
(function () {
  'use strict';
  var C = window.CASE, Art = window.Art, Snd = window.Sound;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var KEY = 'velvetCrown.save.v1';
  var REDUCED = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

  function decode(b64) {
    try { return JSON.parse(decodeURIComponent(escape(atob(b64)))); } catch (e) { return null; }
  }
  function fresh() {
    return { v: 1, names: ['', ''], started: false, elapsed: 0, unlocked: ['A'], read: {}, marks: {}, notes: '', cipher: {},
      hints: { B: 0, C: 0, F: 0 }, gaveUp: {}, accusation: null, music: false, sfx: true, tab: 'file' };
  }
  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) { var o = JSON.parse(raw), f = fresh(); for (var k in f) if (!(k in o)) o[k] = f[k]; return o; }
    } catch (e) { /* private mode or corrupt save */ }
    return fresh();
  }
  var S = load();
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* ignore */ } }

  var VC = window.VC = { $: $, $$: $$, REDUCED: REDUCED, save: save, SECRET: decode(window.VC_SECRET || '') };
  VC.state = function () { return S; };
  VC.reset = function () { try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ } S = fresh(); };

  /* Screens and clock */
  var clockTimer = null, lastTick = 0, ticks = 0;
  VC.fmt = function (ms) {
    var s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0');
  };
  function renderClock() { var el = $('#clock'); if (el) el.textContent = VC.fmt(S.elapsed); }
  function startClock() {
    if (clockTimer) return; lastTick = Date.now(); renderClock();
    clockTimer = setInterval(function () {
      var now = Date.now();
      if (!document.hidden && !S.accusation) S.elapsed += now - lastTick;
      lastTick = now; renderClock(); if (++ticks % 15 === 0) save();
    }, 1000);
  }
  function stopClock() { clearInterval(clockTimer); clockTimer = null; save(); }
  VC.show = function (id) {
    $$('.screen').forEach(function (el) { var on = el.id === id; el.hidden = !on; el.classList.toggle('is-active', on); });
    window.scrollTo(0, 0);
    if (id === 'screen-game') startClock(); else stopClock();
  };

  var toastTimer;
  VC.toast = function (msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('is-on');
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('is-on'); }, 2800);
  };

  /* Modal */
  var lastFocus = null;
  VC.openModal = function (html, opts) {
    opts = opts || {};
    var m = $('#modal'), body = $('#modal-body');
    if (m.hidden) lastFocus = document.activeElement;
    body.innerHTML = html; $('#modal-nav').innerHTML = opts.nav || '';
    m.hidden = false; document.body.classList.add('modal-open');
    $('#modal-sheet').scrollTop = 0;
    m.classList.remove('is-open'); void m.offsetWidth; m.classList.add('is-open');
    if (opts.after) opts.after(body);
    setTimeout(function () { $('#modal-close').focus({ preventScroll: true }); }, 40);
  };
  VC.closeModal = function () {
    var m = $('#modal'); if (m.hidden) return;
    m.hidden = true; m.classList.remove('is-open'); document.body.classList.remove('modal-open');
    $('#modal-body').innerHTML = ''; $('#modal-nav').innerHTML = '';
    if (lastFocus && document.body.contains(lastFocus)) { try { lastFocus.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
  };
  VC.confirm = function (title, text, yes, onYes) {
    VC._onYes = onYes;
    VC.openModal('<div class="confirm"><h3>' + title + '</h3><p>' + text + '</p><div class="confirm-actions">' +
      '<button type="button" class="btn btn-ghost" data-close>Not yet</button><button type="button" class="btn btn-gold" data-confirm-yes>' + yes + '</button></div></div>');
  };

  /* Game header and case file */
  VC.renderTop = function () {
    var n = S.names.filter(Boolean).map(C.esc);
    $('#names-line').textContent = n.length ? 'Detectives ' + n.join(' and ') : 'Case 1114';
    $('#pips').innerHTML = C.envelopes.map(function (e) {
      var open = S.unlocked.indexOf(e.id) > -1;
      return '<span class="pip' + (open ? ' is-open' : '') + '" title="Envelope ' + e.id + (open ? ', open' : ', sealed') + '">' + e.id + '</span>';
    }).join('');
    var acc = $('#btn-accuse'); acc.hidden = S.unlocked.indexOf('C') < 0;
    acc.textContent = S.accusation ? 'See the solution' : 'Make the accusation';
    $('#btn-music').setAttribute('aria-pressed', String(S.music));
    $('#btn-sfx').setAttribute('aria-pressed', String(S.sfx));
  };
  function evCard(ev, i, deal) {
    var rot = ((ev.id.charCodeAt(0) * 7 + ev.id.charCodeAt(1) * 13) % 7 - 3) * .55;
    return '<button type="button" class="ev ev-' + ev.kind + (deal ? ' is-dealt' : '') + '" data-ev="' + ev.id + '" style="--r:' + rot.toFixed(2) + 'deg;--i:' + i + '">' +
      '<span class="ev-art">' + Art.icon(ev.kind) + '</span><span class="ev-no">' + ev.id + '</span>' +
      '<span class="ev-title">' + ev.title + '</span><span class="ev-blurb">' + ev.blurb + '</span>' +
      (S.read[ev.id] ? '' : '<span class="ev-new">Unread</span>') + '</button>';
  }
  VC.renderFile = function (dealEnv) {
    var html = '', next = null;
    C.envelopes.forEach(function (e) {
      if (S.unlocked.indexOf(e.id) > -1) {
        var items = C.evidence.filter(function (ev) { return ev.env === e.id; });
        html += '<section class="env" data-env="' + e.id + '"><header class="env-head"><span class="seal" aria-hidden="true">' + e.id + '</span>' +
          '<div><h2>Envelope ' + e.id + ': ' + e.title + '</h2><p>' + e.line + '</p></div></header><div class="ev-grid">' +
          items.map(function (ev, i) { return evCard(ev, i, dealEnv === e.id); }).join('') + '</div></section>';
      } else if (!next) {
        next = e; html += '<section class="env env-locked" data-env="' + e.id + '">' + VC.lockPanel(e) + '</section>';
      } else {
        html += '<section class="env env-sealed"><header class="env-head"><span class="seal seal-dim" aria-hidden="true">' + e.id + '</span>' +
          '<div><h2>Envelope ' + e.id + '</h2><p>Sealed until envelope ' + next.id + ' is open.</p></div></header></section>';
      }
    });
    if (S.unlocked.indexOf('C') > -1) html += VC.finalPanel();
    $('#file').innerHTML = html;
    if (VC.afterFile) VC.afterFile();
  };
  VC.setTab = function (t) {
    S.tab = t; save();
    $$('[data-tab]').forEach(function (b) { var on = b.dataset.tab === t; b.setAttribute('aria-selected', String(on)); b.classList.toggle('is-on', on); });
    $$('.panel').forEach(function (p) { p.hidden = p.dataset.panel !== t; });
  };
  VC.renderGame = function (dealEnv) {
    VC.renderTop(); VC.renderFile(dealEnv); VC.renderSuspects(); VC.renderNotes(); VC.setTab(S.tab || 'file');
  };
  VC.unlock = function (id) {
    if (S.unlocked.indexOf(id) < 0) S.unlocked.push(id);
    save(); VC.renderTop(); VC.setTab('file'); VC.renderFile(id);
    var sec = $('[data-env="' + id + '"]');
    if (sec) sec.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' });
    Snd.deal(7);
    var env = C.envelopes.filter(function (x) { return x.id === id; })[0];
    setTimeout(function () {
      VC.openModal('<div class="confirm unlock-note"><span class="seal" aria-hidden="true">' + id + '</span>' +
        '<h3>Envelope ' + id + ' is open</h3><p>' + env.title + '. The new evidence is in your case file on screen.</p>' +
        '<p>Playing with the printed case file? Break the seal on your real envelope ' + id + ' now.</p>' +
        '<div class="confirm-actions"><button type="button" class="btn btn-gold" data-close>Let\u2019s see it</button></div></div>');
    }, REDUCED ? 0 : 900);
  };

  /* Evidence viewer */
  VC.openEvidence = function (id, jumpTo) {
    var ev = C.evidence.filter(function (e) { return e.id === id; })[0];
    if (!ev || S.unlocked.indexOf(ev.env) < 0) return;
    var list = C.evidence.filter(function (e) { return S.unlocked.indexOf(e.env) > -1; });
    var i = list.indexOf(ev), prev = list[i - 1], next = list[i + 1];
    var nav = (prev ? '<button type="button" class="btn btn-ghost" data-open="' + prev.id + '">Previous: ' + prev.title + '</button>' : '<span></span>') +
      (next ? '<button type="button" class="btn btn-ghost" data-open="' + next.id + '">Next: ' + next.title + '</button>' : '<span></span>');
    VC.openModal('<p class="doc-label">Evidence ' + ev.id + '</p>' + ev.render({ names: S.names }), {
      nav: nav,
      after: function (root) {
        initLoupe(root); initCipher(root);
        if (jumpTo) { var el = document.getElementById(jumpTo); if (el) setTimeout(function () { el.scrollIntoView({ block: 'start' }); }, 60); }
      }
    });
    if (!S.read[id]) {
      S.read[id] = true; save();
      var badge = $('[data-ev="' + id + '"] .ev-new'); if (badge) badge.remove();
    }
    Snd.flip();
  };

  function initLoupe(root) {
    var wrap = $('[data-loupe]', root); if (!wrap) return;
    var lens = $('.loupe', wrap), inner = $('.loupe-inner', wrap), btn = $('[data-loupe-toggle]', root);
    var Z = 2.6, R = 95, on = !(window.matchMedia && matchMedia('(pointer: coarse)').matches);
    function setOn(v) {
      on = v; btn.setAttribute('aria-pressed', String(v)); btn.textContent = v ? 'Magnifier on' : 'Magnifier off';
      wrap.classList.toggle('loupe-on', v); if (!v) lens.style.opacity = 0;
    }
    setOn(on);
    btn.addEventListener('click', function () { setOn(!on); });
    function move(e) {
      if (!on) return;
      var r = wrap.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      if (x < 0 || y < 0 || x > r.width || y > r.height) { lens.style.opacity = 0; return; }
      lens.style.opacity = 1;
      lens.style.transform = 'translate(' + (x - R) + 'px,' + (y - R) + 'px)';
      inner.style.width = (r.width * Z) + 'px';
      inner.style.transform = 'translate(' + (-(x * Z - R)) + 'px,' + (-(y * Z - R)) + 'px)';
    }
    wrap.addEventListener('pointermove', move);
    wrap.addEventListener('pointerdown', move);
    wrap.addEventListener('pointerleave', function () { lens.style.opacity = 0; });
  }

  function initCipher(root) {
    var box = $('[data-cipher]', root); if (!box) return;
    var inputs = $$('input', box);
    inputs.forEach(function (inp) {
      var i = +inp.dataset.i;
      if (S.cipher[i]) inp.value = S.cipher[i];
      inp.addEventListener('input', function () {
        inp.value = inp.value.replace(/[^a-z]/gi, '').toUpperCase().slice(-1);
        S.cipher[i] = inp.value; save();
        if (inp.value && inputs[i + 1]) inputs[i + 1].focus();
      });
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Backspace' && !inp.value && i > 0) { inputs[i - 1].focus(); e.preventDefault(); }
        else if ((e.key === 'ArrowRight' || e.key === ' ') && inputs[i + 1]) { inputs[i + 1].focus(); e.preventDefault(); }
        else if (e.key === 'ArrowLeft' && i > 0) { inputs[i - 1].focus(); e.preventDefault(); }
      });
    });
    var clr = $('[data-cipher-clear]', root);
    if (clr) clr.addEventListener('click', function () {
      VC.confirm('Clear page 13?', 'This removes every letter you\u2019ve typed under the cards.', 'Clear the letters', function () {
        S.cipher = {}; save(); VC.openEvidence('B3');
      });
    });
  }
})();

/* Velvet Crown: masked portraits of the six suspects. */
(function () {
  'use strict';
  var Art = window.Art;
  var SIL = '#1a0e10', HAIR = '#070304';

  var BUST = {
    isabella: '<path d="M30 240C36 200 66 186 100 184 134 186 164 200 170 240z" fill="' + SIL + '"/>' +
      '<path d="M30 240C38 216 58 208 74 208 84 216 92 222 100 222 108 222 116 216 126 208 142 208 162 216 170 240z" fill="#0f5a43" stroke="#2a9a74" stroke-width="1.2"/>' +
      '<circle cx="62" cy="134" r="3.5" fill="#d9f0e6"/><circle cx="138" cy="134" r="3.5" fill="#d9f0e6"/>',
    marco: '<path d="M24 240C30 198 62 184 100 182 138 184 170 198 176 240z" fill="#0e0e12"/>' +
      '<path d="M86 184 100 232 114 184z" fill="#e9e4d8"/><path d="M86 184 100 232 76 202zM114 184 100 232 124 202z" fill="#20202a"/>' +
      '<path d="M88 188 100 194 112 188v12l-12-6-12 6z" fill="#050506"/>',
    kraus: '<path d="M22 240C28 196 62 182 100 180 138 182 172 196 178 240z" fill="#241a12"/>' +
      '<path d="M66 186C80 198 120 198 134 186L142 206C122 216 78 216 58 206z" fill="#3a2a1a"/>',
    nikolai: '<path d="M14 240C22 194 60 180 100 178 140 180 178 194 186 240z" fill="#0b0b0e"/>' +
      '<path d="M86 182 100 236 70 202zM114 182 100 236 130 202z" fill="#9c7a1c"/><path d="M90 184 100 226 110 184z" fill="#efe9da"/>' +
      '<path d="M89 188 100 194 111 188v12l-11-6-11 6z" fill="#c9a227"/>',
    celeste: '<path d="M30 240C36 200 66 186 100 184 134 186 164 200 170 240z" fill="' + SIL + '"/>' +
      '<path d="M30 240C40 214 64 210 100 214 136 210 160 214 170 240z" fill="#0d0710" stroke="#7a4ea3" stroke-width="1.2"/>',
    tobias: '<path d="M26 240C32 198 64 184 100 182 136 184 168 198 174 240z" fill="#e6e0d2"/>' +
      '<path d="M52 240 72 194 100 222 128 194 148 240z" fill="#6a0f24" stroke="#3a0714" stroke-width="1.5"/>' +
      '<circle cx="100" cy="230" r="2.6" fill="#c9a227"/><circle cx="100" cy="239" r="2.6" fill="#c9a227"/>' +
      '<path d="M88 188 100 194 112 188v12l-12-6-12 6z" fill="#050506"/>'
  };

  var HAIRS = {
    isabella: 'M62 118C56 76 76 58 100 58 126 58 146 76 140 118 146 150 150 176 160 194 140 190 130 172 131 148L132 116C124 96 76 96 68 116L69 148C70 172 60 190 40 194 50 176 54 150 62 118z',
    marco: 'M63 104C62 74 80 60 100 60 122 60 139 74 137 104 131 88 118 80 100 80 82 80 69 88 63 104z',
    kraus: '',
    nikolai: 'M62 102C60 68 84 56 104 57 128 58 142 74 138 102 130 82 112 74 96 76 82 78 70 88 62 102z',
    celeste: 'M58 126C52 78 78 58 100 58 124 58 150 78 142 126 142 138 138 144 130 146L131 112C120 92 80 92 69 112L70 146C62 144 58 138 58 126z',
    tobias: 'M62 102C58 72 76 56 96 57L103 47 109 58 121 51 123 62C137 69 142 85 138 102 130 86 116 80 100 80 84 80 70 87 62 102z'
  };

  var holes = function (fill) {
    return '<ellipse cx="84" cy="107" rx="7" ry="4" fill="' + fill + '"/><ellipse cx="116" cy="107" rx="7" ry="4" fill="' + fill + '"/>' +
      '<circle cx="86" cy="106" r="1.3" fill="#efe6d2"/><circle cx="118" cy="106" r="1.3" fill="#efe6d2"/>';
  };
  var DOMINO = 'M60 104C70 94 90 96 100 102 110 96 130 94 140 104 138 116 124 122 112 118 106 116 102 112 100 112 98 112 94 116 88 118 76 122 62 116 60 104z';

  function mane() {
    var s = '';
    for (var i = 0; i < 22; i++) {
      var a = i / 22 * Math.PI * 2, r0 = 40, r1 = 62 + (i % 2 ? 7 : 0), cx = 100, cy = 106;
      var pt = function (r, t) { return (cx + r * Math.cos(t)).toFixed(1) + ' ' + (cy + r * Math.sin(t)).toFixed(1); };
      s += '<path d="M' + pt(r0, a - .13) + 'L' + pt(r1, a) + 'L' + pt(r0, a + .13) + 'z"/>';
    }
    return '<g fill="url(#g-brass)">' + s + '</g>';
  }

  var MASKS = {
    isabella: '<path d="M100 110C90 92 66 88 58 100 52 112 64 124 84 121 93 120 98 116 100 110zM100 110C110 92 134 88 142 100 148 112 136 124 116 121 107 120 102 116 100 110z" fill="url(#g-silver)" stroke="#f1f1ee" stroke-width=".8"/>' +
      '<path d="M98 100C96 90 90 86 85 84M102 100C104 90 110 86 115 84" stroke="#d8d8d4" stroke-width="1.4" fill="none"/>' + holes('#0b0607') + '<circle cx="100" cy="104" r="3.6" fill="#9fe3d0"/>',
    marco: '<path d="' + DOMINO + '" fill="#0b0507" stroke="#c9a227" stroke-width="1.4"/>' + holes('#2a1a1d'),
    kraus: '<ellipse cx="100" cy="70" rx="74" ry="12" fill="#0e0a08"/><path d="M70 70C70 34 130 34 130 70z" fill="#0e0a08"/><rect x="70" y="61" width="60" height="6" fill="#3a2a1a"/>' +
      '<path d="M64 96C66 84 134 84 136 96L136 118C132 126 122 128 114 128L154 178 106 140C94 136 72 134 64 120z" fill="#e9dfc8" stroke="#8a7a5a" stroke-width="1.2"/>' +
      '<circle cx="84" cy="106" r="9" fill="#22282c" stroke="url(#g-brass)" stroke-width="3"/><circle cx="116" cy="106" r="9" fill="#22282c" stroke="url(#g-brass)" stroke-width="3"/>' +
      '<circle cx="81" cy="103" r="2" fill="#dfe8ea"/><circle cx="113" cy="103" r="2" fill="#dfe8ea"/>',
    nikolai: '<path d="M60 100C68 84 132 84 140 100 142 116 130 126 118 124L100 138 82 124C70 126 58 116 60 100z" fill="url(#g-brass)" stroke="#7a5d10" stroke-width="1.2"/>' +
      holes('#1a0e04') + '<path d="M94 118 100 126 106 118z" fill="#7a5d10"/><path d="M72 96C80 92 88 93 94 98M128 96C120 92 112 93 106 98" stroke="#7a5d10" fill="none"/>',
    celeste: '<g fill="#1c0f24" stroke="#b38fd1" stroke-width=".8"><ellipse cx="136" cy="64" rx="5" ry="28" transform="rotate(12 136 64)"/><ellipse cx="146" cy="70" rx="6" ry="34" transform="rotate(28 146 70)"/><ellipse cx="156" cy="82" rx="5" ry="30" transform="rotate(48 156 82)"/></g>' +
      '<path d="' + DOMINO + '" fill="#120a18" stroke="#b38fd1" stroke-width="1.4"/>' + holes('#2a1a30') +
      '<circle cx="70" cy="106" r="1.1" fill="#e9d8ff"/><circle cx="130" cy="104" r="1.1" fill="#e9d8ff"/><circle cx="100" cy="106" r="1.1" fill="#e9d8ff"/>',
    tobias: '<path d="' + DOMINO + '" fill="#0b0507" stroke="#c9a227" stroke-width="1.4"/>' + holes('#2a1a1d')
  };

  var EXTRA = {
    isabella: '<path d="M91 142Q100 147 109 142 100 139 91 142z" fill="#7d1030"/>',
    kraus: '<path d="M64 112C62 118 63 124 66 128M136 112C138 118 137 124 134 128" stroke="#9a9a9a" stroke-width="3" fill="none"/>',
    marco: '<path d="M64 98C64 108 66 116 68 122M136 98C136 108 134 116 132 122" stroke="#8b8b8b" stroke-width="3" fill="none"/>',
    celeste: '<path d="M90 142Q100 148 110 142 100 138 90 142z" fill="#a3122f"/>',
    tobias: '<g transform="rotate(14 152 170)"><rect x="140" y="148" width="30" height="42" rx="3" fill="#fbf9f3" stroke="#b9b2a2"/><use href="#suit-S" x="147" y="160" width="16" height="16" fill="#1b1411"/></g>' +
      '<ellipse cx="150" cy="190" rx="13" ry="8" fill="#e6e0d2" transform="rotate(-20 150 190)"/>'
  };

  Art.portrait = function (id, cls) {
    var sun = '';
    for (var a = 235; a <= 305; a += 7) {
      var r = a * Math.PI / 180;
      sun += '<path d="M100 236L' + (100 + 132 * Math.cos(r)).toFixed(1) + ' ' + (236 + 132 * Math.sin(r)).toFixed(1) + '"/>';
    }
    var face = '<path d="M86 150h28v36H86z" fill="' + SIL + '"/><ellipse cx="100" cy="110" rx="37" ry="46" fill="' + SIL + '"/>' +
      '<g class="p-eyes"><ellipse cx="84" cy="108" rx="6" ry="2.8" fill="#efe6d2"/><ellipse cx="116" cy="108" rx="6" ry="2.8" fill="#efe6d2"/>' +
      '<circle cx="85" cy="108" r="2.2" fill="#2a1410"/><circle cx="117" cy="108" r="2.2" fill="#2a1410"/>' +
      '<path d="M76 99C82 96 88 96 92 99M108 99C112 96 118 96 124 99M92 140Q100 143 108 140" stroke="#c9a227" stroke-opacity=".7" stroke-width="1.4" fill="none"/></g>';
    return '<svg class="' + (cls || 'portrait') + '" viewBox="0 0 200 240" aria-hidden="true">' +
      '<path d="M8 240V102A92 92 0 0 1 192 102V240z" fill="url(#g-bg-' + id + ')"/>' +
      '<g stroke="#f0d77a" stroke-opacity=".13" stroke-width="2">' + sun + '</g>' +
      (id === 'nikolai' ? mane() : '') +
      BUST[id] + face +
      (HAIRS[id] ? '<path d="' + HAIRS[id] + '" fill="' + HAIR + '"/>' : '') +
      '<path d="M130 84C142 100 142 126 128 150" stroke="#f0d77a" stroke-width="2" fill="none" opacity=".55"/>' +
      (EXTRA[id] || '') +
      '<g class="p-mask">' + MASKS[id] + '</g>' +
      '<path d="M8 240V102A92 92 0 0 1 192 102V240" fill="none" stroke="#c9a227" stroke-width="3"/>' +
      '<path d="M15 240V103A85 85 0 0 1 185 103V240" fill="none" stroke="#c9a227" stroke-opacity=".4"/>' +
      '</svg>';
  };
})();

/* Velvet Crown: game engine, part 2. */
(function () {
  'use strict';
  var VC = window.VC, C = window.CASE, Art = window.Art, Snd = window.Sound;
  var $ = VC.$, $$ = VC.$$, X = VC.SECRET, REDUCED = VC.REDUCED;
  var S = VC.state;

  /* Locks */
  var PHONE = '<svg viewBox="0 0 120 120" aria-hidden="true"><rect x="14" y="58" width="92" height="48" rx="10" fill="#1b1411" stroke="#c9a227" stroke-width="3"/>' +
    '<circle cx="60" cy="82" r="17" fill="none" stroke="#c9a227" stroke-width="3"/><circle cx="60" cy="82" r="5" fill="#c9a227"/>' +
    '<path d="M10 44c0-18 22-26 50-26s50 8 50 26l-4 10H86l-4-12H38l-4 12H14z" fill="#6a0f24" stroke="#c9a227" stroke-width="3"/></svg>';
  VC.lockPanel = function (e) {
    if (e.lock === 'safe') {
      var keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'clear', '0', 'open'].map(function (k) {
        return '<button type="button" class="key' + (k.length > 1 ? ' key-word' : '') + '" data-key="' + k + '">' + (k === 'clear' ? 'Clear' : k === 'open' ? 'Open' : k) + '</button>';
      }).join('');
      return '<div class="lock lock-safe"><div class="safe" id="safe"><div class="safe-door"><div class="safe-screen" id="safe-screen" aria-live="polite">\u2013 \u2013 \u2013 \u2013</div>' +
        '<div class="safe-keys">' + keys + '</div></div></div>' +
        '<div class="lock-copy"><span class="seal" aria-hidden="true">B</span><h2>Envelope B: Victor\u2019s safe</h2>' +
        '<p>A four-digit keypad behind the painting. Victor hid the code for anyone who knew him well, and everything you need is in envelope A.</p>' +
        '<p class="lock-status" id="safe-msg" aria-live="polite"></p><button type="button" class="btn btn-ghost" data-hints="B">Get a hint</button></div></div>';
    }
    return '<div class="lock lock-call"><div class="phone">' + PHONE + '</div><div class="lock-copy"><span class="seal" aria-hidden="true">C</span>' +
      '<h2>Envelope C: call Chief Inspector Duret</h2>' +
      '<p>Duret will send the lab results and search the lockers as soon as you can tell her what page 13 of Victor\u2019s notebook says.</p>' +
      '<form class="call-form" id="call-form" autocomplete="off"><label for="call-input">Page 13 says</label>' +
      '<input id="call-input" type="text" placeholder="Type the decoded message"><button type="submit" class="btn btn-gold">Call the inspector</button></form>' +
      '<p class="lock-status" id="call-msg" aria-live="polite"></p><button type="button" class="btn btn-ghost" data-hints="C">Get a hint</button></div></div>';
  };
  VC.finalPanel = function () {
    var done = !!S().accusation;
    return '<section class="env env-final"><div class="final-card"><h2>' + (done ? 'Case closed' : 'Ready to name the killer?') + '</h2>' +
      '<p>' + (done ? 'You made your accusation. The solution is here whenever you want to read it again.' :
        'When you both agree on who killed Victor, how it was done and why, make your accusation. You get one.') + '</p>' +
      '<div class="final-actions"><button type="button" class="btn btn-gold" data-go-accuse>' + (done ? 'See the solution' : 'Make the accusation') + '</button>' +
      (done ? '' : '<button type="button" class="btn btn-ghost" data-hints="F">Get a hint</button>') + '</div></div></section>';
  };

  var code = '', busy = false;
  function paintSafe() { var s = $('#safe-screen'); if (s) s.textContent = (code + '\u2013\u2013\u2013\u2013').slice(0, 4).split('').join(' '); }
  VC.pressKey = function (k) {
    if (busy || !$('#safe')) return;
    if (k === 'clear') code = '';
    else if (k === 'back') code = code.slice(0, -1);
    else if (k === 'open') { tryCode(); return; }
    else if (code.length < 4) code += k;
    Snd.click(); paintSafe();
    if (code.length === 4) setTimeout(tryCode, 260);
  };
  function tryCode() {
    if (busy || code.length < 4) return;
    busy = true;
    var safe = $('#safe'), msg = $('#safe-msg');
    if (code === X.locks.B) {
      safe.classList.add('is-open'); msg.textContent = 'A heavy click. The door swings open.'; Snd.safe();
      setTimeout(function () { busy = false; code = ''; Snd.chime(); VC.unlock('B'); }, REDUCED ? 300 : 1500);
    } else {
      safe.classList.add('is-wrong'); msg.textContent = 'The safe stays shut. That isn\u2019t the code.'; Snd.wrong();
      setTimeout(function () { safe.classList.remove('is-wrong'); code = ''; paintSafe(); busy = false; }, 700);
    }
  }
  function norm(s) {
    s = String(s || '').toUpperCase();
    if (s.normalize) s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return s.replace(/[^A-Z]/g, '');
  }
  VC.afterFile = function () {
    code = ''; busy = false;
    var f = $('#call-form');
    if (f) f.addEventListener('submit', function (e) {
      e.preventDefault();
      var val = norm($('#call-input').value), msg = $('#call-msg');
      if (!val) { msg.textContent = 'Type what page 13 says first.'; return; }
      var ok = X.locks.C.some(function (k) { return val.indexOf(k) > -1; });
      if (ok) {
        $('#call-input').disabled = true; f.querySelector('button').disabled = true;
        msg.textContent = 'Ringing\u2026'; Snd.ring();
        setTimeout(function () { msg.textContent = X.callReply; }, REDUCED ? 200 : 2300);
        setTimeout(function () { Snd.chime(); VC.unlock('C'); }, REDUCED ? 900 : 5200);
      } else {
        Snd.wrong();
        msg.textContent = 'Duret: \u201cThat doesn\u2019t mean anything to me. Read the page again, card by card.\u201d';
      }
    });
  };

  /* Hints */
  var hintFor = null;
  function hintHtml(w) {
    var list = X.hints[w], used = S().hints[w] || 0, h = '';
    h += '<article class="doc doc-hints"><h3>' + (w === 'F' ? 'Hints for the accusation' : 'Hints for envelope ' + w) + '</h3>' +
      '<p>Hints go from gentle to generous. Open one at a time.</p><ol class="hint-list">';
    for (var i = 0; i < list.length; i++) {
      if (i < used) h += '<li class="hint is-open">' + list[i] + '</li>';
      else if (i === used) h += '<li class="hint"><button type="button" class="btn btn-small" data-hint-next>Show hint ' + (i + 1) + '</button></li>';
      else h += '<li class="hint is-locked">Hint ' + (i + 1) + '</li>';
    }
    h += '</ol>';
    if (X.answers[w]) {
      if (S().gaveUp[w]) h += '<div class="hint-answer">' + X.answers[w] + '</div>';
      else if (used >= list.length) h += '<p><button type="button" class="btn btn-ghost" data-hint-answer>Show the answer</button></p>';
    }
    return h + '</article>';
  }
  VC.openHints = function (w) { hintFor = w; VC.openModal(hintHtml(w)); };
  function hintNext() { var st = S(); st.hints[hintFor] = (st.hints[hintFor] || 0) + 1; VC.save(); Snd.flip(); $('#modal-body').innerHTML = hintHtml(hintFor); }
  function hintAnswer() { S().gaveUp[hintFor] = true; VC.save(); $('#modal-body').innerHTML = hintHtml(hintFor); }

  /* Suspects board and notebook */
  VC.renderSuspects = function () {
    var marks = S().marks;
    $('#board').innerHTML = C.suspects.map(function (s) {
      var m = marks[s.id] || '';
      var b = function (k, label) { return '<button type="button" class="btn btn-small' + (m === k ? ' is-on' : '') + '" data-mark="' + k + '" aria-pressed="' + (m === k) + '">' + label + '</button>'; };
      return '<article class="sus' + (m ? ' is-' + m : '') + '" data-sus="' + s.id + '">' + Art.portrait(s.id) +
        '<div class="sus-body"><h3>' + s.name + '</h3><p>' + s.role + '</p>' +
        '<div class="sus-actions" role="group" aria-label="Your verdict on ' + s.name + '">' + b('suspect', 'Suspicious') + b('cleared', 'Cleared') + '</div>' +
        '<button type="button" class="link" data-dossier="' + s.id + '">Read the file</button></div>' +
        (m === 'cleared' ? '<span class="sus-stamp" aria-hidden="true">Cleared</span>' : '') + '</article>';
    }).join('');
  };
  function mark(id, k) { var st = S(); st.marks[id] = st.marks[id] === k ? '' : k; VC.save(); Snd.click(); VC.renderSuspects(); }
  function dossier(id) {
    var s = C.suspect(id), cOpen = S().unlocked.indexOf('C') > -1;
    VC.openModal('<article class="doc doc-dossier dos-one">' + Art.portrait(id) + '<div><h3>' + s.name + '</h3><p class="dos-role">' + s.role + ', ' + s.age + '</p>' +
      '<dl class="kv kv-tight"><dt>Height</dt><dd>' + s.height + '</dd><dt>Mask tonight</dt><dd>' + s.mask + '</dd><dt>Office keycard</dt><dd>' + s.keycard + '</dd></dl>' +
      '<p>' + s.about + '</p><div class="dos-links"><button type="button" class="btn btn-small" data-open="A6" data-jump-after="A6-' + id + '">First interview</button>' +
      (cOpen ? '<button type="button" class="btn btn-small" data-open="C7" data-jump-after="C7-' + id + '">Second interview</button>' : '') + '</div></div></article>');
  }
  var noteTimer;
  VC.renderNotes = function () { var ta = $('#notes'); if (document.activeElement !== ta) ta.value = S().notes || ''; };

  /* Accusation */
  VC.goAccuse = function () {
    VC.closeModal();
    var st = S();
    if (st.accusation) { VC.reveal(st.accusation.answers, true); return; }
    $('#accuse-form').innerHTML = C.accusation.map(function (q) {
      var opts = q.type === 'suspect' ? C.suspects.map(function (s) {
        return '<label class="opt opt-sus"><input type="radio" name="' + q.id + '" value="' + s.id + '">' + Art.portrait(s.id) + '<span>' + s.name + '</span></label>';
      }).join('') : q.options.map(function (o) {
        return '<label class="opt"><input type="radio" name="' + q.id + '" value="' + o.id + '"><span>' + o.t + '</span></label>';
      }).join('');
      return '<fieldset class="q q-' + q.id + '"><legend>' + q.q + '</legend><div class="opts">' + opts + '</div></fieldset>';
    }).join('') + '<p class="accuse-msg" id="accuse-msg" aria-live="polite"></p><div class="accuse-actions">' +
      '<button type="button" class="btn btn-ghost" data-back-file>Back to the case file</button><button type="submit" class="btn btn-gold">Make the accusation</button></div>';
    VC.show('screen-accuse');
  };
  function submitAccusation(e) {
    e.preventDefault();
    var form = $('#accuse-form'), ans = {}, missing = 0;
    C.accusation.forEach(function (q) { var c = form.querySelector('input[name="' + q.id + '"]:checked'); if (c) ans[q.id] = c.value; else missing++; });
    if (missing) { $('#accuse-msg').textContent = 'Answer all four questions first. ' + missing + ' still open.'; return; }
    var who = C.suspect(ans.who).name;
    VC.confirm('One accusation. No second chances.', 'You are about to accuse ' + who + '. Are you both agreed?', 'We\u2019re sure', function () { VC.reveal(ans, false); });
  }

  function answerText(q, id) {
    if (q.type === 'suspect') return C.suspect(id).name;
    return q.options.filter(function (o) { return o.id === id; })[0].t;
  }
  VC.reveal = function (ans, instant) {
    var st = S(), sol = X.solution, score = 0, res = {};
    C.accusation.forEach(function (q) { res[q.id] = ans[q.id] === sol[q.id]; if (res[q.id]) score++; });
    if (!st.accusation) { st.accusation = { answers: ans, score: score, elapsed: st.elapsed }; VC.save(); }
    VC.show('screen-reveal');
    var killer = C.suspect(sol.who), stage = $('#reveal-stage');
    $('#booklet').hidden = true; $('#booklet').innerHTML = '';
    stage.className = 'reveal-stage';
    stage.innerHTML = '<div class="rv-intro"><p class="rv-line rv-1">Chief Inspector Duret reads your accusation aloud.</p><p class="rv-line rv-2">The killer is\u2026</p></div>' +
      '<div class="rv-card"><div class="rv-flip"><div class="rv-face rv-front">' + Art.crownMark('rv-crown') + '</div>' +
      '<div class="rv-face rv-back">' + Art.portrait(sol.who, 'portrait rv-portrait') + '<h2>' + killer.name + '</h2></div></div></div><div class="rv-result" id="rv-result"></div>';
    function result() {
      var r = !res.who ? X.ratings.wrong : score === 4 ? X.ratings.perfect : score === 3 ? X.ratings.good : X.ratings.who;
      var st2 = S();
      var list = C.accusation.map(function (q) {
        var ok = res[q.id];
        return '<li class="' + (ok ? 'is-ok' : 'is-bad') + '"><span class="v-q">' + q.q + '</span><span class="v-a">You said: ' + answerText(q, ans[q.id]) + '</span>' +
          (ok ? '' : '<span class="v-c">The truth: ' + answerText(q, sol[q.id]) + '</span>') + '</li>';
      }).join('');
      var hints = (st2.hints.B || 0) + (st2.hints.C || 0) + (st2.hints.F || 0);
      $('#rv-result').innerHTML = '<div class="stamp stamp-big">Case closed</div><h3>' + r[0] + '</h3><p class="rv-verdict">' + r[1] + '</p>' +
        '<ul class="verdicts">' + list + '</ul><p class="rv-meta">You got ' + score + ' of 4. Time on the case: ' + VC.fmt(st2.accusation.elapsed) +
        '. Hints used: ' + hints + '.</p><div class="rv-actions"><button type="button" class="btn btn-gold" data-booklet="0">Read what really happened</button>' +
        '<button type="button" class="btn btn-ghost" data-back-file>Back to the case file</button></div>';
      stage.classList.add('is-done');
    }
    if (instant || REDUCED) { stage.classList.add('step-2', 'step-3', 'step-4'); result(); return; }
    Snd.roll(2.6);
    setTimeout(function () { stage.classList.add('step-2'); }, 1300);
    setTimeout(function () { stage.classList.add('step-3'); Snd.thud(); }, 3900);
    setTimeout(function () { stage.classList.add('step-4'); }, 5100);
    setTimeout(function () { result(); Snd.chime(); }, 6400);
  };
  function booklet(i) {
    var ch = X.chapters; i = Math.max(0, Math.min(i, ch.length - 1));
    var b = $('#booklet'); b.hidden = false;
    b.innerHTML = '<article class="booklet-page"><p class="bk-count">Chapter ' + (i + 1) + ' of ' + ch.length + '</p><h2>' + ch[i].title + '</h2>' + ch[i].html +
      '<nav class="bk-nav">' + (i > 0 ? '<button type="button" class="btn btn-ghost" data-booklet="' + (i - 1) + '">Previous chapter</button>' : '<span></span>') +
      (i < ch.length - 1 ? '<button type="button" class="btn btn-gold" data-booklet="' + (i + 1) + '">Next chapter</button>' :
        '<button type="button" class="btn btn-gold" data-new-case>Play again from the start</button>') + '</nav></article>';
    b.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' }); Snd.flip();
  }

  /* Menus */
  var HOWTO = '<article class="doc doc-howto"><h3>How the evening works</h3>' +
    '<p>You are two detectives sharing one case file. Read everything together: the clues hide in plain sight and often only make sense side by side.</p>' +
    '<p>The file comes in three envelopes. The first is open. Crack Victor\u2019s safe to open the second, then decode his notebook to open the third.</p>' +
    '<p>Keep notes in the shared notebook and mark suspects as you rule them in or out. Progress saves itself in this browser, so you can stop and come back.</p>' +
    '<p>Stuck? Every lock has three hints, from gentle to generous.</p>' +
    '<p>When you both agree on who killed Victor, how and why, make your accusation. You get one.</p></article>';
  VC.howTo = function () { VC.openModal(HOWTO); };
  VC.newCase = function () {
    VC.confirm('Start a new case?', 'This clears your progress, notes and hints on this device.', 'Start over', function () { VC.reset(); location.reload(); });
  };
  function menu() {
    VC.openModal('<div class="confirm"><h3>Menu</h3><div class="menu-list">' +
      '<button type="button" class="btn btn-ghost" data-howto>How to play</button>' +
      '<button type="button" class="btn btn-ghost" data-to-title>Back to the title screen</button>' +
      '<button type="button" class="btn btn-ghost" data-new-case>Start over</button></div></div>');
  }

  /* Title and setup */
  function toTitle() {
    VC.closeModal();
    var st = S();
    $('#btn-continue').hidden = !st.started;
    $('#btn-new').textContent = st.started ? 'Start a new case' : 'Open the case file';
    $('#btn-new').className = st.started ? 'btn btn-ghost' : 'btn btn-gold';
    VC.show('screen-title');
  }
  function begin() {
    var st = S();
    st.names = [$('#name1').value.trim().slice(0, 24), $('#name2').value.trim().slice(0, 24)];
    st.started = true; VC.save(); Snd.unlock();
    VC.show('screen-game'); VC.renderGame('A'); Snd.deal(7);
    setTimeout(function () { VC.openEvidence('A1'); }, REDUCED ? 100 : 1500);
  }
  function enterGame() {
    Snd.unlock(); if (S().music) Snd.musicOn();
    VC.show('screen-game'); VC.renderGame();
  }

  /* Wiring */
  function init() {
    var st = S();
    $('#title-wheel').innerHTML = Art.roulette();
    $('#setup-crown').innerHTML = Art.crownMark('crown-mark');
    Snd.setSfx(st.sfx);
    $('#btn-music').setAttribute('aria-pressed', String(st.music));
    $('#btn-sfx').setAttribute('aria-pressed', String(st.sfx));
    toTitle();

    document.addEventListener('click', function (e) {
      var t = e.target.closest('button, [data-close]');
      if (!t) return;
      var d = t.dataset;
      if (d.ev) VC.openEvidence(d.ev);
      else if (d.open) VC.openEvidence(d.open, d.jumpAfter);
      else if (d.jump) { var el = document.getElementById(d.jump); if (el) el.scrollIntoView({ behavior: REDUCED ? 'auto' : 'smooth', block: 'start' }); }
      else if (d.key) VC.pressKey(d.key);
      else if (d.hints) VC.openHints(d.hints);
      else if (t.hasAttribute('data-hint-next')) hintNext();
      else if (t.hasAttribute('data-hint-answer')) hintAnswer();
      else if (d.mark) mark(t.closest('[data-sus]').dataset.sus, d.mark);
      else if (d.dossier) dossier(d.dossier);
      else if (t.hasAttribute('data-go-accuse')) VC.goAccuse();
      else if (t.hasAttribute('data-back-file')) { VC.closeModal(); VC.show('screen-game'); VC.renderGame(); }
      else if (d.booklet !== undefined) booklet(+d.booklet);
      else if (t.hasAttribute('data-new-case')) VC.newCase();
      else if (d.tab) { Snd.click(); VC.setTab(d.tab); }
      else if (t.hasAttribute('data-howto')) VC.howTo();
      else if (t.hasAttribute('data-to-title')) toTitle();
      else if (t.hasAttribute('data-confirm-yes')) { var fn = VC._onYes; VC._onYes = null; VC.closeModal(); if (fn) fn(); }
      else if (t.hasAttribute('data-close')) VC.closeModal();
    });

    $('#btn-new').addEventListener('click', function () {
      var go = function () { Snd.unlock(); $('#name1').value = S().names[0] || ''; $('#name2').value = S().names[1] || ''; VC.show('screen-setup'); setTimeout(function () { $('#name1').focus(); }, 50); };
      if (S().started) VC.confirm('Start a new case?', 'This clears your progress, notes and hints on this device.', 'Start over', function () { VC.reset(); go(); });
      else go();
    });
    $('#btn-continue').addEventListener('click', enterGame);
    $('#btn-title-howto').addEventListener('click', VC.howTo);
    $('#setup-form').addEventListener('submit', function (e) { e.preventDefault(); begin(); });
    $('#btn-setup-back').addEventListener('click', toTitle);
    $('#btn-menu').addEventListener('click', menu);
    $('#btn-accuse').addEventListener('click', VC.goAccuse);
    $('#accuse-form').addEventListener('submit', submitAccusation);
    $('#accuse-form').addEventListener('change', function (e) {
      if (e.target.name) $$('input[name="' + e.target.name + '"]', this).forEach(function (r) { r.closest('.opt').classList.toggle('is-picked', r.checked); });
      Snd.click();
    });
    $('#btn-music').addEventListener('click', function () {
      var st2 = S(); st2.music = !st2.music; VC.save(); this.setAttribute('aria-pressed', String(st2.music));
      if (st2.music) Snd.musicOn(); else Snd.musicOff();
    });
    $('#btn-sfx').addEventListener('click', function () {
      var st2 = S(); st2.sfx = !st2.sfx; VC.save(); Snd.setSfx(st2.sfx); this.setAttribute('aria-pressed', String(st2.sfx)); Snd.click();
    });
    $('#notes').addEventListener('input', function () {
      var ta = this; clearTimeout(noteTimer); $('#notes-saved').textContent = 'Saving\u2026';
      noteTimer = setTimeout(function () { S().notes = ta.value; VC.save(); $('#notes-saved').textContent = 'Saved on this device'; }, 400);
    });
    document.addEventListener('keydown', function (e) {
      var modalOpen = !$('#modal').hidden, tag = (e.target.tagName || '').toLowerCase();
      if (e.key === 'Escape' && modalOpen) { VC.closeModal(); return; }
      if (tag === 'input' || tag === 'textarea') return;
      if (modalOpen && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) {
        var btns = $$('#modal-nav [data-open]');
        var want = e.key === 'ArrowRight' ? 'Next' : 'Previous';
        btns.forEach(function (b) { if (b.textContent.indexOf(want) === 0) b.click(); });
        return;
      }
      if (!modalOpen && $('#safe') && !$('#screen-game').hidden && S().tab === 'file') {
        if (/^[0-9]$/.test(e.key)) VC.pressKey(e.key);
        else if (e.key === 'Backspace') { e.preventDefault(); VC.pressKey('back'); }
        else if (e.key === 'Enter') VC.pressKey('open');
      }
    });
    window.addEventListener('beforeunload', VC.save);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();

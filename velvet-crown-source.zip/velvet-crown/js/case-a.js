/* Velvet Crown: Envelope A, the night of the masquerade. */
(function () {
  'use strict';
  var C = window.CASE, Art = window.Art, esc = C.esc;

  C.add({ id: 'A1', env: 'A', kind: 'letter', title: 'Letter from the Chief Inspector', blurb: 'Your briefing. Read this first.',
    render: function (ctx) {
      var n = ctx.names.filter(Boolean).map(esc);
      var who = n.length === 2 ? 'Detectives ' + n[0] + ' and ' + n[1] : n.length === 1 ? 'Detective ' + n[0] : 'Detectives';
      return '<article class="doc doc-letter">' +
        '<header class="letterhead"><svg class="lh-crest" viewBox="0 0 100 110" aria-hidden="true"><use href="#crest"/></svg>' +
        '<div><p class="lh-org">Monte Verde Criminal Police</p><p class="lh-sub">Office of the Chief Inspector</p></div></header>' +
        '<p class="doc-date">Sunday 15 November, 03:10</p>' +
        '<p>Dear ' + who + ',</p>' +
        '<p>I\u2019m sorry to call you out at this hour, and sorrier about the reason.</p>' +
        '<p>At 00:07 tonight, Victor Valmont was found dead at the desk of his private office above the gaming floor, in the middle of his own party. The Velvet Crown was celebrating forty-five years under his ownership with a masquerade gala: three hundred guests, every one of them in a mask.</p>' +
        '<p>His doctor swears it was no heart attack. So do I. The building was sealed at 00:15 and nobody has left since.</p>' +
        '<p>Six people had reasons to want him gone, and all six were under this roof. Everything we have so far is in this file. As the lab and my officers bring in more, I\u2019ll send it to you in sealed envelopes. Some doors only you can open, though. Victor\u2019s safe, for one: the code died with him.</p>' +
        '<p>Before dawn I need three answers from you: who killed Victor Valmont, how it was done, and why.</p>' +
        '<p>Trust the evidence, not the masks.</p>' +
        '<p class="sign">L\u00e9a Duret</p><p class="sign-sub">Chief Inspector</p></article>';
    } });

  C.add({ id: 'A2', env: 'A', kind: 'report', title: 'Crime scene report', blurb: 'The Crown Office, as the police found it.',
    render: function () {
      return '<article class="doc doc-report">' + C.head('Monte Verde Criminal Police', 'Case 1114') +
        '<h3 class="rep-title">Scene report: the Crown Office</h3>' +
        '<dl class="kv"><dt>Location</dt><dd>Crown Office, first floor, Velvet Crown Casino</dd>' +
        '<dt>Reported</dt><dd>00:07, by Marco Santoro, floor manager, who found the body at 00:04</dd>' +
        '<dt>Building sealed</dt><dd>00:15, by casino security at police request</dd>' +
        '<dt>Police on scene</dt><dd>00:19</dd>' +
        '<dt>Victim</dt><dd>Victor Valmont, 67, owner of the casino since 14 November 1981</dd></dl>' +
        '<h4>The body</h4><p>Seated in the desk chair, slumped forward over the blotter. No wounds and no sign of a struggle. Signs consistent with sudden heart failure; the police surgeon suspects poisoning. Preliminary time of death: between 23:30 and 00:05.</p>' +
        '<h4>On the desk (numbers match photograph 3)</h4><ol class="items">' +
        '<li>A game of patience (Klondike solitaire) in progress, dealt from a fresh deck.</li>' +
        '<li>Crystal glass of cognac, about half full.</li>' +
        '<li>Crystal decanter of cognac, Mr Valmont\u2019s private reserve.</li>' +
        '<li>Ashtray with an unlit cigar.</li><li>Fountain pen.</li>' +
        '<li>Framed wedding photograph, Mr and Mrs Valmont, 2016.</li>' +
        '<li>A book, <i>The Gambler\u2019s Almanac</i>.</li><li>Desk lamp.</li></ol>' +
        '<h4>Elsewhere in the office</h4><ul class="items">' +
        '<li>Waste bin: the cellophane wrapper from a pack of casino playing cards. The numbered security seal on it reads <strong>VC-0431</strong>.</li>' +
        '<li>Under the desk blotter, a note in Mr Valmont\u2019s handwriting:<blockquote class="hand">Nov. \u2014 My four oldest friends keep the code. Ask them in the order of my heart.</blockquote></li>' +
        '<li>Wall safe behind the painting: locked, four-digit keypad. Mrs Valmont states that only her husband knew the code. The manufacturer cannot send a technician before Monday.</li>' +
        '<li>Door: electronic keycard lock. Log requested from casino security.</li>' +
        '<li>Window: locked from the inside.</li></ul>' +
        '<h4>Notes</h4><p>Dr L. Kraus reached the office at 00:12 with Mrs Valmont and announced to everyone present that Mr Valmont had been poisoned. Within half an hour the whole building knew.</p>' +
        '<p>At 00:30, asked for her keycard, Mrs Valmont took it from her evening clutch.</p>' +
        '<div class="stamp">Confidential</div></article>';
    } });

  C.add({ id: 'A3', env: 'A', kind: 'photo', title: 'Crime scene photograph', blurb: 'Victor\u2019s desk at 00:41. Look closely.',
    render: function () {
      return '<article class="doc doc-photo">' +
        '<div class="photo-tools"><button type="button" class="btn btn-small" data-loupe-toggle aria-pressed="true">Magnifier on</button>' +
        '<span>Move over the photo to look closer. Tap the button to switch the magnifier off on a touch screen.</span></div>' +
        '<div class="loupe-wrap" data-loupe>' + Art.deskScene() +
        '<div class="loupe" aria-hidden="true"><div class="loupe-inner">' + Art.deskScene() + '</div></div></div>' +
        '<p class="caption">Photograph 3, taken by the scene officer at 00:41. The numbered markers match the scene report.</p></article>';
    } });

  C.add({ id: 'A4', env: 'A', kind: 'dossier', title: 'The six suspects', blurb: 'Police files on everyone with a motive.',
    render: function () {
      return '<article class="doc doc-dossier"><h3 class="dos-title">The six suspects</h3>' +
        '<p class="dos-note">Heights were measured in the shoes each person wore to the gala.</p><div class="dos-grid">' +
        C.suspects.map(function (s) {
          return '<section class="dos-card">' + Art.portrait(s.id, 'portrait') + '<div><h4>' + s.name + '</h4>' +
            '<p class="dos-role">' + s.role + ', ' + s.age + '</p><dl class="kv kv-tight"><dt>Height</dt><dd>' + s.height + '</dd>' +
            '<dt>Mask tonight</dt><dd>' + s.mask + '</dd><dt>Office keycard</dt><dd>' + s.keycard + '</dd></dl><p>' + s.about + '</p></div></section>';
        }).join('') + '</div></article>';
    } });

  C.add({ id: 'A5', env: 'A', kind: 'programme', title: 'Gala programme', blurb: 'The evening\u2019s schedule, as printed.',
    render: function () {
      var rows = [['20:30', 'Doors open. Guests without a mask receive a white Bauta at the entrance.'],
        ['21:00', 'Welcome from Victor Valmont and the anniversary spin of the wheel'],
        ['22:00', 'Celeste Moreau sings <i>Midnight Blue</i>, a jazz set in the Grand Salon'],
        ['22:45', 'Final table of the Anniversary Poker Classic, Salon Priv\u00e9, by invitation'],
        ['23:00', 'A surprise in the Grand Salon'],
        ['23:30', 'Masked auction for the Monte Verde Children\u2019s Hospital'],
        ['00:00', 'Unmasking at midnight and a champagne toast']];
      return '<article class="doc doc-programme"><div class="prog-inner">' + Art.crownMark('prog-crown') +
        '<p class="prog-kicker">The Velvet Crown</p><h3 class="prog-title">Forty-five years</h3>' +
        '<p class="prog-sub">Anniversary Masquerade Gala, Saturday 14 November</p><ol class="prog-list">' +
        rows.map(function (r) { return '<li><time>' + r[0] + '</time><span>' + r[1] + '</span></li>'; }).join('') +
        '</ol><p class="prog-foot">Black tie and masks, please. The house wishes you luck.</p></div></article>';
    } });

  C.add({ id: 'A6', env: 'A', kind: 'statements', title: 'First interviews', blurb: 'Statements taken between 01:00 and 02:30.',
    render: function () {
      var d = 'A6';
      return '<article class="doc doc-statements">' + C.head('Case 1114', 'First interviews, 01:00 to 02:30') +
        C.jump(d, ['isabella', 'marco', 'kraus', 'nikolai', 'celeste', 'tobias']) +
        C.statement(d, 'isabella', '<p>Victor opened the night at nine with his speech and the anniversary spin. You should have seen him, like a boy with a new toy.</p>' +
          '<p>From a quarter to eleven I watched the final table in the Salon Priv\u00e9. I\u2019ll admit I was there to watch Nikolai play. Even the dealer was in a playful mood: at about ten to eleven he made my wedding ring vanish from my finger, and it turned up in Nikolai\u2019s champagne. Everyone laughed. My clutch was right there on the rail beside me.</p>' +
          '<p>At five to eleven I slipped backstage. Celeste and I sang the surprise duet from eleven until twenty-five past, and Victor sat in the front row the whole time, grinning. Afterwards he went upstairs for his Last Hand, as he does every night, and I went back to the Salon Priv\u00e9.</p>' +
          '<p>My keycard? In my clutch, where it always is. And no, I don\u2019t know the safe code. Victor had his sayings about cards. \u201cLove, work, money, trouble: hearts, spades, diamonds, clubs. That\u2019s the order of my heart.\u201d He had it engraved on his cigar case.</p>') +
        C.statement(d, 'marco', '<p>Every night since 1981, at half past eleven, Victor plays one hand of solitaire with a brand-new sealed deck. The Last Hand, he calls it. Win it and tomorrow is lucky. The whole staff knows about it.</p>' +
          '<p>At 21:55 I signed tonight\u2019s deck out of the Cage and took it up at 22:01, same as always. He wasn\u2019t in the office. I left it sealed on the blotter and came straight back down.</p>' +
          '<p>From 23:05 I was in the Cage with Mirela for the midnight count. At 00:04 I carried the takings upstairs and found him. I called security at once.</p>' +
          '<p>He was a superstitious man. He kept four cards from his very first deck, yellow as old piano keys, hidden around that desk. \u201cMy oldest friends,\u201d he called them. And forty years at the tables, he still licked his thumb before every card he dealt. I never broke him of it.</p>') +
        C.statement(d, 'kraus', '<p>Victor and I had words at the bar at about half past ten. About money, if you must know, and it\u2019s nobody\u2019s business but ours.</p>' +
          '<p>From a quarter to eleven I played the final table of the Poker Classic. I didn\u2019t leave my seat until after midnight. Ask anyone at that table.</p>' +
          '<p>I\u2019ve been Victor\u2019s doctor for thirty years. His heart was as strong as an ox\u2019s. That\u2019s why I said it the moment I saw him: this was no natural death. Somebody poisoned him.</p>') +
        C.statement(d, 'nikolai', '<p>I came to play cards, Inspector, not to kill my competition. Yes, I offered Victor sixty million for this old palace. Yes, he laughed in my face. Three times.</p>' +
          '<p>From 22:45 I sat at the final table. I was chip leader by midnight; you can check. I barely saw Victor all evening. He was downstairs, watching his wife sing.</p>' +
          '<p>Why would I need him dead? With the Aurora Palace across the bay, the Velvet Crown was dying on its own.</p>') +
        C.statement(d, 'celeste', '<p>My first set ran from ten until a quarter to eleven. Then I rested in my dressing room until the duet with Isabella: eleven until about twenty-five past, in front of three hundred people. After that I stayed backstage until the unmasking.</p>' +
          '<p>Victor held my contract like a leash. Three more years. But I sing for a living, Inspector. I don\u2019t poison old men.</p>' +
          '<p>My father was a performer too, you know. He died when I was nine. I\u2019ve had enough death for one life.</p>') +
        C.statement(d, 'tobias', '<p>I dealt the final table from a quarter to eleven. My break was 23:05 to 23:20. I went out onto the terrace for a cigarette and some air; the Salon gets hot with all those masks. Nobody saw me, I suppose. It was just me and the sea.</p>' +
          '<p>Mr Valmont tipped well and remembered everyone\u2019s name. Beyond that I hardly knew him.</p>' +
          '<p>The ring? A little trick for Mrs Valmont. Guests like a bit of magic with their cards. It\u2019s good for tips.</p>') +
        '</article>';
    } });

  C.add({ id: 'A7', env: 'A', kind: 'plan', title: 'Floor plan', blurb: 'Both floors, the doors and the cameras.',
    render: function () {
      return '<article class="doc doc-plan"><div class="plan-frame">' + Art.floorPlan() + '</div>' +
        '<div class="plan-notes"><h4>Notes from the scene officer</h4>' +
        '<p>The Crown Office can only be reached by the private stairs from the staff corridor. Camera 04 watches the landing outside the office door.</p>' +
        '<p>Walking times, measured tonight: Salon Priv\u00e9 to the office door by the staff corridor, 40 seconds. Stage to the office door, 55 seconds. Terrace to the Salon Priv\u00e9, 30 seconds.</p>' +
        '<p>There are no cameras in the staff corridor, in the Salon Priv\u00e9 or on the terrace.</p></div></article>';
    } });
})();

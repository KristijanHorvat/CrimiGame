/* Velvet Crown: Envelope C, lab results and lockers. */
(function () {
  'use strict';
  var C = window.CASE;

  C.add({ id: 'C1', env: 'C', kind: 'report', title: 'Autopsy report', blurb: 'Cause and time of death.',
    render: function () {
      return '<article class="doc doc-report">' + C.head('Institute of Forensic Medicine', 'Case 1114') +
        '<h3 class="rep-title">Post-mortem examination: Victor Valmont, 67</h3>' +
        '<dl class="kv"><dt>Cause of death</dt><dd>Heart failure caused by acute poisoning with a cardiac glycoside, a heart poison of the foxglove family.</dd>' +
        '<dt>Time of death</dt><dd>Between 23:40 and 00:00.</dd>' +
        '<dt>Route</dt><dd>By mouth. First symptoms would appear ten to twenty minutes after the first dose.</dd></dl>' +
        '<h4>Findings</h4><ul class="items">' +
        '<li>Traces of the poison on the tongue and lips, and on the tips of the right thumb and index finger.</li>' +
        '<li>Stomach: a small amount of cognac. No food since about 20:00.</li>' +
        '<li>Heart healthy for his age. No heart medication prescribed and none in his blood.</li></ul>' +
        '<h4>Remarks</h4><p>The pattern of residue, on the fingertips and the tongue, suggests many small doses carried to the mouth by the fingers rather than one poisoned drink.</p></article>';
    } });

  C.add({ id: 'C2', env: 'C', kind: 'lab', title: 'Forensic lab report', blurb: 'What the poison was, and where it was.',
    render: function () {
      return '<article class="doc doc-report">' + C.head('Police forensic laboratory', 'Case 1114') +
        '<h3 class="rep-title">Toxicology and trace evidence</h3>' +
        '<table class="ledger"><thead><tr><th>Item</th><th>Result</th></tr></thead><tbody>' +
        '<tr><td>Solitaire cards from the desk, all 52</td><td class="pos">Poison on the corners of every card</td></tr>' +
        '<tr><td>Cognac glass</td><td>Negative</td></tr><tr><td>Cognac decanter</td><td>Negative</td></tr>' +
        '<tr><td>Cigar</td><td>Negative. Unlit and untouched.</td></tr><tr><td>Fountain pen</td><td>Negative</td></tr>' +
        '<tr><td>Cellophane wrapper, seal VC-0431</td><td>No poison on the outside. No fingerprints at all: wiped clean. The seam carries two lines of glue, the factory\u2019s and a second one applied by hand. The pack had been opened and expertly resealed.</td></tr>' +
        '</tbody></table><h4>The poison</h4>' +
        '<p>A crude plant extract of <i>Digitalis purpurea</i>, the common foxglove. There were no tablet binders or fillers in it, so it was not made from pharmaceutical pills.</p>' +
        '<p>For comparison, the digoxin tablets from Dr Kraus\u2019s medical bag are a standard pharmaceutical product. They do not match.</p></article>';
    } });

  C.add({ id: 'C3', env: 'C', kind: 'log', title: 'The Cage: deck register', blurb: 'Every deck issued and returned tonight.',
    render: function () {
      return '<article class="doc doc-log">' + C.head('The Cage', 'Deck issue register') +
        '<p class="log-sub">Every deck carries a numbered security seal on its cellophane. The numbers are unique and logged when a deck is issued.</p>' +
        '<table class="ledger"><thead><tr><th>Time</th><th>Seals</th><th>Issued to</th><th>Signed</th></tr></thead><tbody>' +
        '<tr><td>20:00</td><td>VC-0429 to VC-0432</td><td>Salon Priv\u00e9, table 1 (4 decks)</td><td>T. Grey</td></tr>' +
        '<tr><td>20:00</td><td>VC-0433 to VC-0448</td><td>Blackjack tables 1 to 4 (16 decks)</td><td>A. Kova\u010d, J. Ricci</td></tr>' +
        '<tr><td>21:55</td><td>VC-0917</td><td>Crown Office, Mr Valmont\u2019s Last Hand</td><td>M. Santoro</td></tr></tbody></table>' +
        '<h4>Midnight count</h4><table class="ledger"><tbody>' +
        '<tr><td>23:05</td><td>Count opened in the Cage by M. Santoro and M. Begi\u0107</td></tr>' +
        '<tr><td>23:19</td><td>Count closed and signed by M. Santoro and M. Begi\u0107</td></tr></tbody></table>' +
        '<h4>Reconciliation at close, 00:40, under police supervision</h4>' +
        '<table class="ledger"><thead><tr><th>Station</th><th>Issued</th><th>Returned</th><th>Remarks</th></tr></thead><tbody>' +
        '<tr><td>Salon Priv\u00e9, table 1</td><td>4</td><td>3: VC-0429, VC-0430, VC-0432</td><td>VC-0431: \u201cdiscarded at 21:30, drink spilled on it. T.G.\u201d No discarded deck was found in the Salon Priv\u00e9 bins.</td></tr>' +
        '<tr><td>Blackjack 1 to 4</td><td>16</td><td>16</td><td>None</td></tr>' +
        '<tr><td>Crown Office</td><td>1: VC-0917</td><td>Not returned</td><td>In the office, per procedure</td></tr></tbody></table></article>';
    } });

  C.add({ id: 'C4', env: 'C', kind: 'log', title: 'Salon Priv\u00e9 records', blurb: 'Dealer rotation and the hand history.',
    render: function () {
      var hands = [[38, '23:01', 'T. Grey'], [39, '23:04', 'T. Grey'], [40, '23:07', 'A. Kova\u010d'], [41, '23:10', 'A. Kova\u010d'], [42, '23:13', 'A. Kova\u010d'],
        [43, '23:16', 'A. Kova\u010d'], [44, '23:19', 'A. Kova\u010d'], [45, '23:22', 'T. Grey'], [46, '23:26', 'T. Grey'], [47, '23:29', 'T. Grey']];
      return '<article class="doc doc-log">' + C.head('Anniversary Poker Classic', 'Salon Priv\u00e9, table 1') +
        '<h3 class="rep-title">Dealer rotation</h3><table class="ledger"><thead><tr><th>Dealer</th><th>Dealing</th><th>On break</th></tr></thead><tbody>' +
        '<tr><td>T. Grey</td><td>20:30\u201321:40, 21:55\u201323:05, 23:20\u201300:30</td><td>21:40\u201321:55, 23:05\u201323:20</td></tr>' +
        '<tr><td>A. Kova\u010d</td><td>Covers table 1 during T. Grey\u2019s breaks, otherwise blackjack 2</td><td>None</td></tr></tbody></table>' +
        '<h3 class="rep-title">Hand history, final table</h3>' +
        '<p class="log-sub">Seats: 1 N. Petrov, 2 L. Kraus, 3 H. Duval, 4 K. Okafor, 5 A. Lindqvist. A player who leaves the table is marked as sitting out and is not dealt in. Nobody sat out between 22:45 and 23:52.</p>' +
        '<table class="ledger ledger-mono"><thead><tr><th>Hand</th><th>Time</th><th>Dealer</th><th>Seats dealt in</th></tr></thead><tbody>' +
        hands.map(function (h) { return '<tr><td>#' + h[0] + '</td><td>' + h[1] + '</td><td>' + h[2] + '</td><td>1 2 3 4 5</td></tr>'; }).join('') +
        '</tbody></table></article>';
    } });

  C.add({ id: 'C5', env: 'C', kind: 'locker', title: 'Locker search', blurb: 'The staff roster and what the lockers held.',
    render: function () {
      var roster = [['03', 'Marco Santoro, floor manager'], ['07', 'Ana Kova\u010d, dealer'], ['12', 'Luka Petri\u0107, bartender'],
        ['16', 'Mirela Begi\u0107, cashier'], ['21', 'Tobias Grey, dealer'], ['24', 'Jonas Ricci, dealer']];
      return '<article class="doc doc-report">' + C.head('Monte Verde Criminal Police', 'Case 1114') +
        '<h3 class="rep-title">Search of staff lockers and dressing rooms, 02:00 to 03:00</h3>' +
        '<p>No member of staff had left the building since it was sealed at 00:15.</p>' +
        '<h4>Staff roster: locker numbers</h4><table class="ledger ledger-narrow"><tbody>' +
        roster.map(function (r) { return '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>'; }).join('') + '</tbody></table>' +
        '<h4>What we found</h4><dl class="kv kv-wide">' +
        '<dt>Locker 03</dt><dd>Jacket, cigarettes, and a second, handwritten ledger of \u201cadjustments\u201d to the nightly count, September to November, totalling \u20ac40,000.</dd>' +
        '<dt>Locker 07</dt><dd>Street clothes, a paperback novel, hand cream.</dd>' +
        '<dt>Locker 12</dt><dd>Bar knives, a racing paper, a jar of cocktail cherries.</dd>' +
        '<dt>Locker 16</dt><dd>Calculator, lunch box, knitting.</dd>' +
        '<dt>Locker 21</dt><dd>Street clothes. A sealed deck of Velvet Crown cards, seal <strong>VC-0917</strong>, cellophane intact. A white Bauta mask of the kind handed out to guests, folded in a napkin. A pair of thin black gloves. Magician\u2019s props: a thumb tip, flash paper, cellophane sheets, a glue pen and a small heat sealer. An empty amber dropper bottle, hand-labelled <i>Fingerhut</i>. A faded photograph of a stage magician with a small boy on his shoulders. On the back: <span class="hand-inline">F\u00fcr Tobi, von deinem Papa, dem Grauen Geist. 1999</span></dd>' +
        '<dt>Locker 24</dt><dd>Street clothes, a gym bag.</dd>' +
        '<dt>Dressing room A, Mrs Valmont</dt><dd>Gowns. A bundle of love letters signed \u201cN.\u201d</dd>' +
        '<dt>Dressing room B, Ms Moreau</dt><dd>Throat spray. A contract offer from the Aurora Palace: two million for three years. A photograph of a little girl on the shoulders of a man holding a trumpet, marked \u201cPapa, Cirque Lumi\u00e8re, 1998\u201d.</dd>' +
        '<dt>Cloakroom ticket 118, Dr Kraus</dt><dd>Medical bag, searched with his consent: stethoscope, prescription pad, a box of digoxin 0.25 mg tablets prescribed to L. Kraus (30 in the box, 28 left), and a stack of IOUs.</dd></dl></article>';
    } });

  C.add({ id: 'C6', env: 'C', kind: 'news', title: 'Newspaper clippings', blurb: 'Monte Verde Courier, 2004 and 2009.',
    render: function () {
      return '<article class="doc doc-news"><div class="clip"><p class="np-mast">Monte Verde Courier</p><p class="np-date">Friday 12 March 2004</p>' +
        '<h3 class="np-head">\u201cGrey Ghost\u201d jailed for casino fraud</h3><p class="np-deck">Velvet Crown\u2019s star illusionist gets six years after the owner\u2019s testimony</p>' +
        '<div class="np-cols"><p>Anton Grauer, 44, the Austrian illusionist who packed the Velvet Crown\u2019s cabaret for a decade as the Grey Ghost (<i>Der Graue Geist</i>), was sentenced yesterday to six years in prison for cheating at the casino\u2019s high-stakes tables.</p>' +
        '<p>The case rested largely on the evidence of casino owner Victor Valmont, who told the court he had personally watched Grauer switch marked cards into play.</p>' +
        '<p>Grauer, famous for his signature illusion, the Vanishing Ring, denied the charges to the end. \u201cI have never cheated at cards,\u201d he told reporters on the court steps. \u201cOnly at magic.\u201d</p>' +
        '<p>His wife Margit and their son, aged eight, will return to her family in Innsbruck.</p></div></div>' +
        '<div class="clip clip-small"><p class="np-date">Monte Verde Courier, Thursday 3 December 2009</p><h4 class="np-head-sm">Illusionist dies in prison</h4>' +
        '<p>Anton Grauer, 49, once celebrated as the Grey Ghost, died of pneumonia on Tuesday in Monte Verde prison, three months before his release. He always maintained his innocence.</p></div></article>';
    } });

  C.add({ id: 'C7', env: 'C', kind: 'statements', title: 'Second interviews', blurb: 'Everyone, confronted with the evidence.',
    render: function () {
      var d = 'C7';
      return '<article class="doc doc-statements">' + C.head('Case 1114', 'Second interviews, 04:00 to 05:00') +
        C.jump(d, ['isabella', 'marco', 'kraus', 'nikolai', 'celeste', 'tobias', 'ana', 'mirela', 'luka']) +
        C.statement(d, 'isabella', '<p>A new will? I knew nothing about it. Victor never talked about money with me.</p>' +
          '<p>My keycard never left my clutch, I swear it. Well, the clutch left my hand twice. At ten to eleven, during the dealer\u2019s ring trick, it lay on the rail right beside him. And when I came back to the Salon Priv\u00e9 at about 23:35, I knocked it off the rail. The same dealer, Tobias, picked it up and handed it back to me. Such lovely hands.</p>' +
          '<p>Nikolai and I\u2026 yes. Since the summer. That isn\u2019t murder.</p>') +
        C.statement(d, 'marco', '<p>All right. I took money from the count. Forty thousand. I meant to put it back before he noticed. But I didn\u2019t kill him.</p>' +
          '<p>I carried deck VC-0917 up at 22:01, sealed, and I signed for it. I never went back up until midnight. Ask Mirela.</p>') +
        C.statement(d, 'kraus', '<p>The digoxin is mine, for my own heart. Two tablets gone this week, and both of them are inside me.</p>' +
          '<p>Yes, I owe Victor money, and yes, I said something foolish at the bar. But I was dealt into every hand at that table. Check the history.</p>') +
        C.statement(d, 'nikolai', '<p>Isabella and I have been close since the summer. That is not a crime in Monte Verde.</p>' +
          '<p>I was in every hand from eleven until half past. The table\u2019s own records will tell you so. And at my height, Inspector, I am hard to mistake for anyone else.</p>') +
        C.statement(d, 'celeste', '<p>The Grey Ghost? I\u2019ve never heard the name. My father played trumpet in a travelling circus band. He died in a road accident when I was nine.</p>' +
          '<p>And the poison: everyone backstage knew by half past twelve. Dr Kraus was shouting it down the corridor.</p>') +
        C.statement(d, 'tobias', '<p>Deck 0431? Somebody knocked a gin and tonic over it at half past nine. Wet cards are useless, so I threw them away and noted it. That\u2019s procedure.</p>' +
          '<p>The terrace. Alone. I needed air.</p>' +
          '<p>The photograph in my locker is my father. He was a magician. Lots of people\u2019s fathers were something. Grey is my name. It always has been.</p>') +
        C.statement(d, 'ana', '<p>I took over the final table at 23:05 and handed it back to Tobias at 23:20 exactly. He came back out of breath and pink in the face. Not like someone who\u2019d been smoking on a terrace. More like someone who\u2019d taken the stairs two at a time.</p>' +
          '<p>And a spilled drink at half past nine? Not at that table. I brought the players their drinks myself, and everything was dry.</p>') +
        C.statement(d, 'mirela', '<p>Marco was in the Cage with me from 23:05 until we signed off the count at 23:19. He never left. There\u2019s a camera over the Cage door if you want to check.</p>' +
          '<p class="officer">Officer\u2019s note: camera 02 confirms it.</p>') +
        C.statement(d, 'luka', '<p>The doctor and Mr Valmont had words at my bar around half past ten. The doctor said something like, \u201cYou\u2019ll get your money over my dead body, or yours.\u201d Then he stormed off to the Salon Priv\u00e9.</p>') +
        '</article>';
    } });
})();

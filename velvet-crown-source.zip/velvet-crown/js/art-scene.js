/* Velvet Crown: the police photograph of Victor's desk. */
(function () {
  'use strict';
  var Art = window.Art;

  function marker(x, y, n) {
    return '<g transform="translate(' + x + ' ' + y + ')"><path d="M0 34 14 0 28 34z" fill="#f2c230" stroke="#1b1411" stroke-width="1.5"/>' +
      '<text x="14" y="29" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="15" fill="#1b1411">' + n + '</text></g>';
  }
  function oct(r) {
    var p = [];
    for (var i = 0; i < 8; i++) { var a = Math.PI / 8 + i * Math.PI / 4; p.push((r * Math.cos(a)).toFixed(1) + ',' + (r * Math.sin(a)).toFixed(1)); }
    return p.join(' ');
  }

  Art.deskScene = function () {
    var c = Art.card, s = '';
    s += '<svg class="scene" viewBox="0 0 1200 800" role="img" aria-label="Police photograph of Victor Valmont\'s desk, taken at 00:41">';
    s += '<rect width="1200" height="800" fill="url(#g-wood)"/>';
    for (var i = 0; i < 15; i++) {
      var y = 20 + i * 54 + (i % 3) * 9;
      s += '<path d="M0 ' + y + 'C300 ' + (y + 16) + ' 640 ' + (y - 18) + ' 1200 ' + (y + 8) + '" stroke="#1c0d06" stroke-width="' + (1 + i % 3) + '" fill="none" opacity=".32"/>';
    }

    /* The note under the blotter: only its top edge shows. */
    s += '<g transform="rotate(-3 440 140)"><rect x="436" y="134" width="190" height="72" fill="#efe6d2"/>' +
      '<text x="452" y="160" font-family="Caveat,cursive" font-size="21" fill="#2a1e5c">Nov. \u2014 My four</text></g>';

    /* Hidden old card: 4 of clubs, under the corner of the blotter. */
    s += c(200, 548, '4', 'C', { old: true, rot: -16 });

    /* Blotter */
    s += '<rect x="250" y="170" width="720" height="470" rx="10" fill="#15402f" stroke="#7a5d1a" stroke-width="4"/>';
    s += '<rect x="264" y="184" width="692" height="442" rx="6" fill="none" stroke="#c9a227" stroke-opacity=".45" stroke-dasharray="2 5"/>';
    s += '<path d="M250 170h70L250 240zM970 170h-70L970 240zM250 640h70L250 570zM970 640h-70L970 570z" fill="#3b1a10" opacity=".92"/>';

    /* Solitaire in progress (item 1) */
    s += c(292, 196, '', '', { back: true }) + c(296, 192, '', '', { back: true });
    s += c(378, 194, '6', 'D');
    for (var k = 0; k < 4; k++) {
      s += '<rect x="' + (600 + k * 88) + '" y="194" width="62" height="88" rx="6" fill="none" stroke="#c9a227" stroke-opacity=".5" stroke-dasharray="4 4"/>';
    }
    s += c(600, 194, 'A', 'H') + c(688, 194, 'A', 'S');
    var tops = [['K', 'S'], ['Q', 'D'], ['8', 'C'], ['J', 'H'], ['3', 'S'], ['10', 'D'], ['5', 'C']];
    for (var col = 0; col < 7; col++) {
      var x = 292 + col * 94, yy = 316;
      for (var b = 0; b < col; b++) { s += c(x, yy, '', '', { back: true }); yy += 14; }
      s += c(x, yy, tops[col][0], tops[col][1]);
      if (col === 4) s += c(x, yy + 28, '2', 'H');
    }

    /* Decanter (item 3) and glass (item 2) */
    s += '<g transform="translate(1070 150)"><polygon points="' + oct(74) + '" fill="#000" opacity=".25" transform="translate(6 8)"/>' +
      '<polygon points="' + oct(72) + '" fill="url(#g-amber)" opacity=".88" stroke="#f6e6c0" stroke-opacity=".6" stroke-width="2"/>' +
      '<polygon points="' + oct(48) + '" fill="none" stroke="#fff" stroke-opacity=".25"/>' +
      '<circle r="20" fill="url(#g-crystal)" stroke="#fff" stroke-opacity=".6"/><path d="M-50-30-30-50" stroke="#fff" stroke-opacity=".5" stroke-width="4" stroke-linecap="round"/></g>';
    s += '<g transform="translate(1065 330)"><circle r="62" fill="#2a1409"/><circle r="52" fill="url(#g-crystal)" stroke="#f5f1e6" stroke-width="3"/>' +
      '<circle r="36" fill="url(#g-amber)" opacity=".9"/><ellipse cx="-14" cy="-16" rx="12" ry="6" fill="#fff" opacity=".35"/></g>';

    /* Hidden old card: 7 of hearts, under the ashtray. */
    s += c(985, 540, '7', 'H', { old: true, rot: 28 });
    /* Ashtray with unlit cigar (item 4) */
    s += '<g transform="translate(1060 610)"><circle r="80" fill="#000" opacity=".25" transform="translate(6 8)"/>' +
      '<circle r="78" fill="url(#g-crystal)" stroke="#e9eef0" stroke-width="3"/><circle r="50" fill="#3a3a3a" opacity=".35"/>' +
      '<g transform="rotate(-24)"><rect x="-86" y="-11" width="150" height="22" rx="11" fill="#6b3a1c"/><rect x="30" y="-11" width="14" height="22" fill="url(#g-brass)"/>' +
      '<path d="M-80-6h120" stroke="#8a5530" stroke-opacity=".6"/></g></g>';

    /* Banker's lamp (item 8) */
    s += '<circle cx="650" cy="84" r="40" fill="url(#g-brass)" opacity=".9"/>' +
      '<rect x="520" y="36" width="260" height="64" rx="32" fill="url(#g-lamp)" stroke="#0a2a18" stroke-width="2"/>' +
      '<path d="M548 52h204" stroke="#bff0cf" stroke-opacity=".45" stroke-width="5" stroke-linecap="round"/>';

    /* Framed wedding photograph (item 6), with hidden 2 of spades tucked in the corner. */
    s += '<g transform="translate(40 40) rotate(-5)"><rect width="170" height="210" rx="4" fill="url(#g-silver)" stroke="#555"/>' +
      '<rect x="16" y="16" width="138" height="178" fill="#b89b72"/>' +
      '<circle cx="64" cy="80" r="14" fill="#3a2a1c"/><path d="M40 194C42 140 52 104 64 100 76 104 86 140 88 194z" fill="#3a2a1c"/>' +
      '<path d="M86 194C88 150 96 110 106 104 116 110 126 150 132 194z" fill="#efe4cc"/><circle cx="106" cy="84" r="13" fill="#5a4330"/>' +
      '<path d="M94 80C96 66 118 66 120 80L128 150 110 96z" fill="#f7efdf" opacity=".8"/>' +
      '<rect x="16" y="16" width="138" height="178" fill="url(#g-vignette)"/></g>';
    s += c(168, 20, '2', 'S', { old: true, rot: 24 });

    /* Book (item 7), with hidden 9 of diamonds as a bookmark. */
    s += c(92, 290, '9', 'D', { old: true, rot: -3 });
    s += '<g transform="translate(40 330) rotate(3)"><rect width="160" height="240" rx="6" fill="#5a2415" stroke="#2a0e06" stroke-width="2"/>' +
      '<rect x="12" y="12" width="136" height="216" rx="3" fill="none" stroke="#c9a227" stroke-opacity=".7"/>' +
      '<text x="80" y="100" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="17" fill="#e8c872">The Gambler\'s</text>' +
      '<text x="80" y="124" text-anchor="middle" font-family="Georgia,serif" font-style="italic" font-size="17" fill="#e8c872">Almanac</text>' +
      '<use href="#crown" x="60" y="150" width="40" height="30" fill="#c9a227"/></g>';

    /* Fountain pen (item 5) */
    s += '<g transform="translate(700 704) rotate(-14)"><rect width="190" height="14" rx="7" fill="#0d0d0f"/>' +
      '<rect x="146" width="22" height="14" fill="url(#g-brass)"/><path d="M190 2 214 7 190 12z" fill="url(#g-brass)"/></g>';

    s += marker(262, 128, 1) + marker(990, 398, 2) + marker(985, 58, 3) + marker(958, 672, 4) +
      marker(640, 690, 5) + marker(214, 262, 6) + marker(100, 592, 7) + marker(800, 54, 8);

    s += '<rect width="1200" height="800" fill="url(#g-flash)"/><rect width="1200" height="800" fill="url(#g-vignette)" opacity=".5"/>';
    s += '<rect y="764" width="1200" height="36" fill="#000" opacity=".62"/>' +
      '<text x="20" y="788" font-family="Courier New,monospace" font-size="17" fill="#f2efe6">Case 1114   Photo 3   Crown Office desk   00:41</text>';
    s += '</svg>';
    return s;
  };
})();

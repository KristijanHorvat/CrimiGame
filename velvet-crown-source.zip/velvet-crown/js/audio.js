/* Velvet Crown: all sound is generated live, no audio files. */
window.Sound = (function () {
  'use strict';
  var ctx = null, master, music, sfx, timer = null, nextTime = 0, beat = 0, playing = false, sfxOn = true, noiseBuf = null;
  var SPB = 60 / 72;
  var mtof = function (m) { return 440 * Math.pow(2, (m - 69) / 12); };

  function init() {
    if (ctx) return true;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    try { ctx = new AC(); } catch (e) { return false; }
    master = ctx.createGain(); master.gain.value = .9; master.connect(ctx.destination);
    music = ctx.createGain(); music.gain.value = 0; music.connect(master);
    var d = ctx.createDelay(1), fb = ctx.createGain(), wet = ctx.createGain(), lp = ctx.createBiquadFilter();
    d.delayTime.value = SPB * .75; fb.gain.value = .26; wet.gain.value = .2; lp.type = 'lowpass'; lp.frequency.value = 2200;
    music.connect(d); d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(wet); wet.connect(master);
    sfx = ctx.createGain(); sfx.gain.value = .55; sfx.connect(master);
    return true;
  }
  function resume() { if (ctx && ctx.state === 'suspended') ctx.resume(); }

  function ep(freq, t, dur, vel, dest) {
    var o1 = ctx.createOscillator(), o2 = ctx.createOscillator(), g = ctx.createGain(), g2 = ctx.createGain(), f = ctx.createBiquadFilter();
    o1.type = 'sine'; o2.type = 'sine'; o1.frequency.value = freq; o2.frequency.value = freq * 2.005;
    g2.gain.value = .18; f.type = 'lowpass'; f.frequency.value = 1800;
    o1.connect(g); o2.connect(g2); g2.connect(g); g.connect(f); f.connect(dest || music);
    g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(vel, t + .012);
    g.gain.exponentialRampToValueAtTime(vel * .35, t + .35); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o1.start(t); o2.start(t); o1.stop(t + dur + .05); o2.stop(t + dur + .05);
  }
  function bass(freq, t, dur) {
    var o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
    o.type = 'triangle'; o.frequency.value = freq; f.type = 'lowpass'; f.frequency.value = 600;
    o.connect(f); f.connect(g); g.connect(music);
    g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.32, t + .02);
    g.gain.exponentialRampToValueAtTime(.1, t + dur * .6); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.start(t); o.stop(t + dur + .05);
  }
  function noise() {
    if (noiseBuf) return noiseBuf;
    var len = ctx.sampleRate; noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    var data = noiseBuf.getChannelData(0);
    for (var i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    return noiseBuf;
  }
  function hiss(t, vel, dest, dur, freq) {
    var s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noise(); f.type = 'bandpass'; f.frequency.value = freq || 6000; f.Q.value = .8;
    s.connect(f); f.connect(g); g.connect(dest || music); dur = dur || .18;
    g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(vel, t + .01); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    s.start(t); s.stop(t + dur + .02);
  }

  /* Dm9, G13, Cmaj9, A7(b9): two bars each, with a walking bass. */
  var CH = [[53, 57, 60, 64], [53, 57, 59, 64], [52, 55, 59, 62], [55, 58, 61, 64]];
  var BASS = [[38, 41, 45, 41], [38, 45, 43, 44], [43, 47, 50, 47], [43, 41, 38, 37], [36, 40, 43, 40], [36, 40, 43, 44], [45, 49, 52, 49], [45, 43, 40, 39]];
  function schedule() {
    while (nextTime < ctx.currentTime + .4) {
      var bar = Math.floor(beat / 4) % 8, b = beat % 4, chord = CH[Math.floor(bar / 2)];
      bass(mtof(BASS[bar][b]), nextTime, SPB * .95);
      if (b === 0) chord.forEach(function (m, i) { ep(mtof(m), nextTime + i * .012, SPB * 2.6, .065); });
      if (b === 1) chord.forEach(function (m) { ep(mtof(m), nextTime + SPB * .66, SPB * 1.2, .04); });
      if (b === 1 || b === 3) hiss(nextTime, .045);
      hiss(nextTime + SPB * .66, .018);
      nextTime += SPB; beat++;
    }
  }
  function fx(fn) { if (!sfxOn || !init()) return; resume(); try { fn(ctx.currentTime); } catch (e) { /* ignore */ } }
  function thudAt(t) {
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine'; o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(45, t + .25);
    g.gain.setValueAtTime(.5, t); g.gain.exponentialRampToValueAtTime(.0001, t + .35);
    o.connect(g); g.connect(sfx); o.start(t); o.stop(t + .4); hiss(t, .2, sfx, .12, 900);
  }

  return {
    unlock: function () { if (init()) resume(); },
    musicOn: function () {
      if (!init()) return; resume(); if (playing) return; playing = true;
      music.gain.cancelScheduledValues(ctx.currentTime); music.gain.setTargetAtTime(.55, ctx.currentTime, .8);
      nextTime = ctx.currentTime + .1; clearInterval(timer); timer = setInterval(schedule, 100);
    },
    musicOff: function () {
      if (!ctx || !playing) return; playing = false;
      music.gain.setTargetAtTime(0, ctx.currentTime, .3);
      setTimeout(function () { if (!playing) { clearInterval(timer); timer = null; } }, 1500);
    },
    setSfx: function (v) { sfxOn = !!v; },
    flip: function () { fx(function (t) { hiss(t, .25, sfx, .09, 3500); }); },
    deal: function (n) { fx(function (t) { for (var i = 0; i < (n || 1); i++) hiss(t + i * .09, .22, sfx, .08, 3000 + (i % 3) * 600); }); },
    click: function () {
      fx(function (t) {
        var o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'square'; o.frequency.value = 1200;
        g.gain.setValueAtTime(.04, t); g.gain.exponentialRampToValueAtTime(.0001, t + .04); o.connect(g); g.connect(sfx); o.start(t); o.stop(t + .05);
      });
    },
    chime: function () { fx(function (t) { [72, 76, 79, 84, 88].forEach(function (m, i) { ep(mtof(m), t + i * .09, 1.6, .12, sfx); }); }); },
    wrong: function () {
      fx(function (t) {
        [0, .16].forEach(function (d) {
          var o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
          o.type = 'sawtooth'; o.frequency.value = d ? 98 : 110; f.type = 'lowpass'; f.frequency.value = 500;
          o.connect(f); f.connect(g); g.connect(sfx);
          g.gain.setValueAtTime(.0001, t + d); g.gain.exponentialRampToValueAtTime(.16, t + d + .02); g.gain.exponentialRampToValueAtTime(.0001, t + d + .14);
          o.start(t + d); o.stop(t + d + .16);
        });
      });
    },
    thud: function () { fx(function (t) { thudAt(t); }); },
    safe: function () { fx(function (t) { for (var i = 0; i < 4; i++) hiss(t + i * .11, .3, sfx, .04, 2200); thudAt(t + .5); }); },
    ring: function () {
      fx(function (t) {
        for (var r = 0; r < 2; r++) for (var k = 0; k < 14; k++) ep(k % 2 ? 1320 : 1175, t + r * 1.1 + k * .05, .09, .05, sfx);
      });
    },
    roll: function (sec) {
      fx(function (t) {
        var s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain(), lfo = ctx.createOscillator(), lg = ctx.createGain();
        s.buffer = noise(); s.loop = true; f.type = 'bandpass'; f.frequency.value = 260; f.Q.value = .7;
        lfo.frequency.value = 17; lg.gain.value = .1; lfo.connect(lg); lg.connect(g.gain);
        g.gain.setValueAtTime(.0001, t); g.gain.linearRampToValueAtTime(.2, t + sec);
        s.connect(f); f.connect(g); g.connect(sfx); s.start(t); lfo.start(t); s.stop(t + sec); lfo.stop(t + sec);
        hiss(t + sec, .45, sfx, 1.4, 4500);
        [50, 57, 62, 65].forEach(function (m) { ep(mtof(m), t + sec, 2.2, .18, sfx); });
      });
    }
  };
})();

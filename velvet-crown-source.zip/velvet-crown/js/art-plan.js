/* Velvet Crown: floor plan of the casino. */
(function () {
  'use strict';
  var Art = window.Art;
  var INK = '#2b2320', ROOM = '#f7f0e0';

  function room(x, y, w, h, label, sub, fill) {
    var s = '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + (fill || ROOM) + '" stroke="' + INK + '" stroke-width="3"/>';
    if (label) s += '<text x="' + (x + w / 2) + '" y="' + (y + h / 2 + (sub ? -4 : 6)) + '" text-anchor="middle" class="pl-label">' + label + '</text>';
    if (sub) s += '<text x="' + (x + w / 2) + '" y="' + (y + h / 2 + 16) + '" text-anchor="middle" class="pl-sub">' + sub + '</text>';
    return s;
  }
  function gap(x, y, w, h) { return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + ROOM + '"/>'; }
  function cam(x, y, label, rot) {
    return '<g transform="translate(' + x + ' ' + y + ') rotate(' + (rot || 0) + ')"><path d="M4 0 70 -24 70 24z" fill="#f2c230" opacity=".28"/>' +
      '<rect x="-12" y="-7" width="18" height="14" rx="2" fill="' + INK + '"/><path d="M6-4 12-6v12L6 4z" fill="' + INK + '"/></g>' +
      '<text x="' + (x + 2) + '" y="' + (y - 13) + '" class="pl-cam" text-anchor="middle">' + label + '</text>';
  }

  Art.floorPlan = function () {
    var s = '<svg class="plan" viewBox="0 0 1000 660" role="img" aria-label="Floor plan of the Velvet Crown casino, ground floor and first floor">';
    s += '<style>.pl-label{font:italic 600 19px "Cormorant Garamond",Georgia,serif;fill:' + INK + '}.pl-sub{font:13px "Cormorant Garamond",Georgia,serif;fill:#5a4a3c}.pl-cam{font:700 11px Arial,sans-serif;fill:#7a5d10}.pl-note{font:italic 14px "Cormorant Garamond",Georgia,serif;fill:#5a4a3c}</style>';
    s += '<rect width="1000" height="660" fill="#efe6d2"/><g stroke="#ddd1b4">';
    for (var gx = 0; gx <= 1000; gx += 20) s += '<path d="M' + gx + ' 0V660"/>';
    for (var gy = 0; gy <= 660; gy += 20) s += '<path d="M0 ' + gy + 'H1000"/>';
    s += '</g>';

    /* Back of house */
    s += room(40, 40, 120, 80, 'Dressing A', 'Mrs Valmont') + room(160, 40, 120, 80, 'Dressing B', 'Ms Moreau');
    s += room(280, 40, 190, 80, '', '');
    for (var l = 0; l < 10; l++) s += '<rect x="' + (292 + l * 17) + '" y="50" width="13" height="24" fill="#e2d6bb" stroke="' + INK + '"/>';
    s += '<text x="375" y="104" text-anchor="middle" class="pl-label">Staff lockers</text>';
    s += room(470, 40, 90, 80, '', '');
    for (var st = 0; st < 9; st++) s += '<path d="M' + (478 + st * 9) + ' 46V88" stroke="' + INK + '" stroke-width="1.2"/>';
    s += '<text x="515" y="104" text-anchor="middle" class="pl-sub">Private stairs</text><path d="M515 94V70m-6 8 6-8 6 8" stroke="#a3122f" stroke-width="2" fill="none"/>';
    s += room(560, 40, 260, 80, 'Service and kitchen', '');
    s += room(40, 120, 780, 40, '', '', '#ece2cb');
    s += '<text x="300" y="146" text-anchor="middle" class="pl-sub">Staff corridor (no cameras)</text>';

    /* Public floor */
    s += room(40, 160, 430, 310, '', '');
    s += '<rect x="44" y="164" width="86" height="302" fill="#e3d3b0"/><text transform="translate(92 315) rotate(-90)" text-anchor="middle" class="pl-label">Stage</text>';
    for (var ry = 200; ry <= 440; ry += 30) for (var rx = 170; rx <= 440; rx += 30) s += '<circle cx="' + rx + '" cy="' + ry + '" r="3.2" fill="#b8a88a"/>';
    s += '<rect x="230" y="296" width="180" height="40" fill="' + ROOM + '" opacity=".9"/><text x="320" y="323" text-anchor="middle" class="pl-label">Grand Salon</text>';
    s += room(470, 160, 90, 310, '', '');
    s += '<text transform="translate(520 315) rotate(-90)" text-anchor="middle" class="pl-sub">Hall</text>';
    s += room(560, 160, 260, 190, '', '');
    s += '<ellipse cx="690" cy="262" rx="72" ry="36" fill="#2f6b4f" stroke="' + INK + '" stroke-width="2"/>';
    [[690, 214], [630, 226], [750, 226], [618, 282], [762, 282], [690, 310]].forEach(function (p, i) {
      s += '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="9" fill="' + (i === 5 ? '#a3122f' : '#e2d6bb') + '" stroke="' + INK + '"/>';
    });
    s += '<text x="690" y="190" text-anchor="middle" class="pl-label">Salon Priv\u00e9</text><text x="690" y="336" text-anchor="middle" class="pl-sub">red seat: dealer</text>';
    s += room(560, 350, 260, 120, 'The Cage', 'cashier and deck store');
    s += room(40, 470, 260, 130, '', '');
    s += '<path d="M70 500Q170 560 270 500" stroke="' + INK + '" stroke-width="10" fill="none" opacity=".75"/><text x="170" y="582" text-anchor="middle" class="pl-label">Le Tr\u00e8fle bar</text>';
    s += room(300, 470, 260, 130, 'Entrance', 'and cloakroom');
    s += room(560, 470, 260, 130, 'Gaming floor', 'roulette and blackjack');
    s += '<rect x="820" y="160" width="130" height="310" fill="#e3e8d3" stroke="' + INK + '" stroke-width="2" stroke-dasharray="8 6"/>';
    s += '<text x="885" y="300" text-anchor="middle" class="pl-label">Terrace</text><text x="885" y="320" text-anchor="middle" class="pl-sub">outside</text><text x="885" y="336" text-anchor="middle" class="pl-sub">no camera</text>';

    /* Doors */
    s += gap(495, 117, 40, 6) + gap(590, 157, 35, 6) + gap(817, 220, 6, 40) + gap(557, 262, 6, 36) + gap(60, 157, 36, 6) +
      gap(467, 300, 6, 40) + gap(490, 467, 50, 6) + gap(400, 597, 60, 6) + gap(557, 395, 6, 30) + gap(200, 467, 40, 6) +
      gap(557, 520, 6, 40) + gap(85, 117, 30, 6) + gap(205, 117, 30, 6) + gap(360, 117, 40, 6) + gap(680, 117, 40, 6);

    /* Cameras */
    s += cam(430, 588, 'Cam 01', -90) + cam(572, 410, 'Cam 02', 180) + cam(700, 588, 'Cam 03', -90);

    /* First floor inset */
    s += '<rect x="836" y="486" width="154" height="164" fill="#f3ead6" stroke="' + INK + '" stroke-width="2"/>';
    s += '<text x="913" y="506" text-anchor="middle" class="pl-label">First floor</text>';
    s += room(846, 514, 134, 82, '', '');
    s += '<text x="905" y="556" text-anchor="middle" class="pl-label">Crown Office</text>';
    s += '<rect x="956" y="520" width="18" height="18" fill="#bfb49a" stroke="' + INK + '"/><circle cx="965" cy="529" r="5" fill="none" stroke="' + INK + '"/>';
    s += '<text x="965" y="550" text-anchor="middle" class="pl-sub">safe</text>';
    s += room(846, 596, 134, 46, '', '');
    for (var fs = 0; fs < 6; fs++) s += '<path d="M' + (930 + fs * 8) + ' 600V638" stroke="' + INK + '" stroke-width="1"/>';
    s += '<text x="890" y="626" text-anchor="middle" class="pl-sub">Landing</text>' + gap(876, 593, 30, 6);
    s += cam(862, 612, 'Cam 04', -60);

    /* Legend */
    s += '<g transform="translate(40 626)"><rect x="0" y="-8" width="16" height="12" rx="2" fill="' + INK + '"/><text x="24" y="3" class="pl-note">CCTV camera</text>' +
      '<rect x="130" y="-10" width="30" height="16" fill="#e3e8d3" stroke="' + INK + '" stroke-dasharray="5 4"/><text x="168" y="3" class="pl-note">outside</text>' +
      '<path d="M260 0h100M260-5v10M360-5v10" stroke="' + INK + '" stroke-width="2"/><text x="370" y="4" class="pl-note">10 metres</text></g>';
    s += '</svg>';
    return s;
  };
})();

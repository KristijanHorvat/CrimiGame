/* Velvet Crown: shared art. Every picture in the game is SVG drawn in code. */
(function () {
  'use strict';
  var Art = (window.Art = {});
  var RED = '#a3122f', INK = '#1b1411';

  var SPRITE = `
<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" style="position:absolute;width:0;height:0;overflow:hidden"><defs>
<symbol id="suit-H" viewBox="0 0 100 100"><path d="M50 90C22 66 5 48 5 29 5 15 16 5 29 5c9 0 16 5 21 13C55 10 62 5 71 5c13 0 24 10 24 24 0 19-17 37-45 61z"/></symbol>
<symbol id="suit-D" viewBox="0 0 100 100"><path d="M50 3 86 50 50 97 14 50z"/></symbol>
<symbol id="suit-S" viewBox="0 0 100 100"><path d="M50 4C62 24 94 40 94 62c0 14-10 22-22 22-8 0-15-4-19-10 1 10 5 17 13 22H34c8-5 12-12 13-22-4 6-11 10-19 10C16 84 6 76 6 62 6 40 38 24 50 4z"/></symbol>
<symbol id="suit-C" viewBox="0 0 100 100"><circle cx="50" cy="27" r="21"/><circle cx="27" cy="58" r="21"/><circle cx="73" cy="58" r="21"/><path d="M45 50h10c0 22 4 34 14 46H31c10-12 14-24 14-46z"/></symbol>
<symbol id="crown" viewBox="0 0 120 90"><path d="M8 70 16 24 38 50 60 12 82 50 104 24 112 70z"/><rect x="8" y="75" width="104" height="11" rx="2"/><circle cx="16" cy="18" r="6"/><circle cx="60" cy="7" r="7"/><circle cx="104" cy="18" r="6"/></symbol>
<symbol id="crest" viewBox="0 0 100 110"><path d="M50 4 92 18v34c0 28-18 46-42 54C26 98 8 80 8 52V18z" fill="none" stroke="currentColor" stroke-width="6"/><path d="M50 26l7 15 16 2-12 11 3 16-14-8-14 8 3-16-12-11 16-2z"/></symbol>
<linearGradient id="g-wood" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3c2012"/><stop offset=".45" stop-color="#4d2a17"/><stop offset="1" stop-color="#26130a"/></linearGradient>
<radialGradient id="g-vignette" cx=".5" cy=".45" r=".78"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".7"/></radialGradient>
<radialGradient id="g-flash" cx=".5" cy=".4" r=".5"><stop offset="0" stop-color="#fff6dc" stop-opacity=".16"/><stop offset="1" stop-color="#fff6dc" stop-opacity="0"/></radialGradient>
<pattern id="p-cardback" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" fill="#6b1026"/><rect width="4" height="4" fill="#841a33"/></pattern>
<linearGradient id="g-old" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e4cf98"/><stop offset=".6" stop-color="#d4b675"/><stop offset="1" stop-color="#bb9856"/></linearGradient>
<radialGradient id="g-amber" cx=".38" cy=".36" r=".72"><stop offset="0" stop-color="#f0b454"/><stop offset=".6" stop-color="#b8661c"/><stop offset="1" stop-color="#6b300a"/></radialGradient>
<linearGradient id="g-brass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6df91"/><stop offset=".5" stop-color="#bf9725"/><stop offset="1" stop-color="#7a5d10"/></linearGradient>
<linearGradient id="g-silver" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f4f2"/><stop offset=".5" stop-color="#a9aaa8"/><stop offset="1" stop-color="#5f605e"/></linearGradient>
<linearGradient id="g-lamp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3fa06d"/><stop offset=".5" stop-color="#17643e"/><stop offset="1" stop-color="#0b3a22"/></linearGradient>
<radialGradient id="g-crystal" cx=".4" cy=".35" r=".7"><stop offset="0" stop-color="#ffffff" stop-opacity=".55"/><stop offset=".7" stop-color="#bfc6c9" stop-opacity=".25"/><stop offset="1" stop-color="#8f989c" stop-opacity=".45"/></radialGradient>
<radialGradient id="g-cone" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#8a6420"/><stop offset=".55" stop-color="#4a2c10"/><stop offset="1" stop-color="#2a170a"/></radialGradient>
<pattern id="p-scan" width="4" height="4" patternUnits="userSpaceOnUse"><rect width="4" height="2" fill="#000" opacity=".28"/></pattern>
<filter id="f-grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" stitchTiles="stitch"/><feColorMatrix values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 .5 0"/></filter>
<radialGradient id="g-bg-isabella" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#1e7a5c"/><stop offset="1" stop-color="#062a20"/></radialGradient>
<radialGradient id="g-bg-marco" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#5a5a66"/><stop offset="1" stop-color="#15151a"/></radialGradient>
<radialGradient id="g-bg-kraus" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#7a6034"/><stop offset="1" stop-color="#1d160c"/></radialGradient>
<radialGradient id="g-bg-nikolai" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#9a6d14"/><stop offset="1" stop-color="#2a1c04"/></radialGradient>
<radialGradient id="g-bg-celeste" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#5e3580"/><stop offset="1" stop-color="#160a20"/></radialGradient>
<radialGradient id="g-bg-tobias" cx=".5" cy=".35" r=".8"><stop offset="0" stop-color="#a0183a"/><stop offset="1" stop-color="#2a0510"/></radialGradient>
</defs></svg>`;

  function inject() {
    if (!document.getElementById('suit-H')) document.body.insertAdjacentHTML('afterbegin', SPRITE);
  }
  if (document.body) inject(); else document.addEventListener('DOMContentLoaded', inject);

  var isRed = function (s) { return s === 'H' || s === 'D'; };

  /* A playing card for use inside larger SVG scenes. */
  Art.card = function (x, y, rank, suit, o) {
    o = o || {};
    var w = o.w || 62, h = o.h || 88, rot = o.rot || 0, old = !!o.old;
    var t = 'translate(' + x + ' ' + y + ') rotate(' + rot + ')';
    if (o.back) {
      return '<g transform="' + t + '"><rect width="' + w + '" height="' + h + '" rx="6" fill="#f4efe3" stroke="#bdb6a6"/>' +
        '<rect x="4" y="4" width="' + (w - 8) + '" height="' + (h - 8) + '" rx="4" fill="url(#p-cardback)" stroke="#c9a227" stroke-width=".8"/></g>';
    }
    var col = old ? (isRed(suit) ? '#8c2c18' : '#3a2614') : (isRed(suit) ? RED : INK);
    var idx = '<text x="6" y="18" font-family="Georgia,serif" font-weight="700" font-size="16" fill="' + col + '">' + rank + '</text>' +
      '<use href="#suit-' + suit + '" x="6" y="22" width="12" height="12" fill="' + col + '"/>';
    return '<g transform="' + t + '">' +
      '<rect width="' + w + '" height="' + h + '" rx="6" fill="' + (old ? 'url(#g-old)' : '#fbf9f3') + '" stroke="' + (old ? '#8f7240' : '#b9b2a2') + '" stroke-width="1.2"/>' +
      idx + '<use href="#suit-' + suit + '" x="' + (w / 2 - 13) + '" y="' + (h / 2 - 11) + '" width="26" height="26" fill="' + col + '" opacity="' + (old ? .85 : 1) + '"/>' +
      '<g transform="rotate(180 ' + w / 2 + ' ' + h / 2 + ')">' + idx + '</g>' +
      (old ? '<path d="M5 ' + h * .72 + ' q' + w * .3 + ' -7 ' + w * .62 + ' 3 M' + w * .2 + ' 6 q6 10 2 22" stroke="#8f7240" fill="none" opacity=".45"/>' : '') +
      '</g>';
  };

  /* Small card for HTML (cipher, shorthand card). */
  Art.mini = function (rank, suit) {
    return '<span class="mcard ' + (isRed(suit) ? 'is-red' : 'is-black') + '"><b>' + rank + '</b>' +
      '<svg viewBox="0 0 100 100" aria-hidden="true"><use href="#suit-' + suit + '"/></svg></span>';
  };
  Art.suit = function (s) {
    return '<svg class="suit ' + (isRed(s) ? 'is-red' : 'is-black') + '" viewBox="0 0 100 100" role="img" aria-label="' +
      ({ H: 'hearts', S: 'spades', D: 'diamonds', C: 'clubs' })[s] + '"><use href="#suit-' + s + '"/></svg>';
  };

  var ICONS = {
    letter: '<rect x="6" y="12" width="36" height="25" rx="2"/><path d="M6 14l18 14 18-14"/><circle cx="24" cy="31" r="4" fill="currentColor"/>',
    report: '<rect x="10" y="5" width="28" height="38" rx="1"/><path d="M15 13h18M15 18h18M15 23h14M15 28h18"/><rect x="24" y="33" width="10" height="5"/>',
    photo: '<rect x="8" y="6" width="32" height="36" rx="1"/><rect x="12" y="10" width="24" height="22"/><path d="M12 28l7-7 5 5 4-3 8 7"/><circle cx="30" cy="15" r="2"/>',
    dossier: '<path d="M5 13h14l4 4h20v22H5z"/><path d="M14 9v10a3 3 0 0 0 6 0V8"/>',
    programme: '<rect x="12" y="4" width="24" height="40" rx="1"/><rect x="15" y="7" width="18" height="34"/><path d="M18 21l2-6 4 4 4-4 2 6z" fill="currentColor"/>',
    statements: '<path d="M6 10h36v20H22l-8 8v-8H6z"/><path d="M12 17h24M12 23h16"/>',
    plan: '<rect x="5" y="8" width="38" height="32"/><path d="M5 22h16v18M21 8v8M29 22h14M29 22v10"/>',
    notebook: '<rect x="11" y="5" width="26" height="38" rx="2" fill="currentColor" fill-opacity=".25"/><path d="M32 5v38M11 12h-3M11 20h-3M11 28h-3M11 36h-3"/>',
    card: '<rect x="13" y="6" width="22" height="34" rx="3"/><path d="M24 17c-4-5-9-1-6 3l6 7 6-7c3-4-2-8-6-3z" fill="currentColor"/>',
    log: '<rect x="7" y="6" width="34" height="36" rx="1"/><path d="M7 14h34M7 22h34M7 30h34M18 6v36"/>',
    cctv: '<path d="M6 14l26-6 3 11-26 6z"/><path d="M20 23l2 9h-8M14 32v8M35 13l7 1"/>',
    film: '<rect x="4" y="10" width="40" height="28"/><path d="M4 16h40M4 32h40"/><path d="M8 13h3M16 13h3M24 13h3M32 13h3M8 35h3M16 35h3M24 35h3M32 35h3"/>',
    lab: '<path d="M19 5h10M21 5v14L10 38a3 3 0 0 0 3 4h22a3 3 0 0 0 3-4L27 19V5"/><path d="M15 30h18"/>',
    news: '<rect x="5" y="8" width="38" height="32" rx="1"/><path d="M10 14h28M10 20h12M10 25h12M10 30h12M10 35h12"/><rect x="26" y="19" width="12" height="17"/>',
    locker: '<rect x="13" y="4" width="22" height="40" rx="1"/><path d="M17 10h14M17 13h14M17 16h14M29 26v6"/>',
    safe: '<rect x="7" y="7" width="34" height="34" rx="2"/><circle cx="24" cy="24" r="8"/><path d="M24 16v3M24 29v3M16 24h3M29 24h3"/>',
    will: '<path d="M12 6h22v36H12z"/><path d="M16 13h14M16 18h14M16 23h10"/><path d="M26 32l4 4 8-9"/>'
  };
  Art.icon = function (kind) {
    return '<svg class="icon" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      (ICONS[kind] || ICONS.report) + '</svg>';
  };

  /* European roulette wheel for the title screen. */
  Art.roulette = function () {
    var order = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
    var reds = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];
    var n = 37, R1 = 292, R0 = 214, s = '';
    s += '<svg class="roulette" viewBox="-330 -330 660 660" aria-hidden="true">';
    s += '<circle r="326" fill="#24110a"/><circle r="318" fill="none" stroke="url(#g-brass)" stroke-width="7"/>';
    s += '<circle r="304" fill="#170b07"/>';
    s += '<g class="roulette-wheel">';
    for (var i = 0; i < n; i++) {
      var a0 = (i - .5) * 2 * Math.PI / n - Math.PI / 2, a1 = (i + .5) * 2 * Math.PI / n - Math.PI / 2;
      var p = function (r, a) { return (r * Math.cos(a)).toFixed(1) + ' ' + (r * Math.sin(a)).toFixed(1); };
      var num = order[i];
      var fill = num === 0 ? '#0f5a3a' : (reds.indexOf(num) > -1 ? '#8e1026' : '#120d0f');
      s += '<path d="M' + p(R0, a0) + 'L' + p(R1, a0) + 'A' + R1 + ' ' + R1 + ' 0 0 1 ' + p(R1, a1) + 'L' + p(R0, a1) + 'A' + R0 + ' ' + R0 + ' 0 0 0 ' + p(R0, a0) + 'z" fill="' + fill + '" stroke="#c9a227" stroke-width="1.2"/>';
      var deg = i * 360 / n;
      s += '<text transform="rotate(' + deg.toFixed(2) + ') translate(0 -268)" text-anchor="middle" dominant-baseline="middle" font-family="Georgia,serif" font-size="19" fill="#efe6d2">' + num + '</text>';
    }
    s += '<circle r="' + R0 + '" fill="url(#g-cone)" stroke="#c9a227" stroke-width="2"/>';
    s += '<circle r="150" fill="none" stroke="#c9a227" stroke-opacity=".35"/>';
    for (var k = 0; k < 4; k++) {
      s += '<g transform="rotate(' + (k * 90 + 45) + ')"><rect x="-6" y="-176" width="12" height="150" rx="6" fill="url(#g-brass)"/><circle cy="-180" r="11" fill="url(#g-brass)"/></g>';
    }
    s += '<circle r="34" fill="url(#g-brass)"/><circle r="12" fill="#5c430c"/>';
    s += '</g><g class="roulette-ball"><circle cy="-304" r="9" fill="#fbf7ec"/><circle cx="-3" cy="-307" r="3" fill="#fff"/></g>';
    s += '</svg>';
    return s;
  };

  Art.crownMark = function (cls) {
    return '<svg class="' + (cls || 'crown-mark') + '" viewBox="0 0 120 90" aria-hidden="true"><use href="#crown"/></svg>';
  };
})();

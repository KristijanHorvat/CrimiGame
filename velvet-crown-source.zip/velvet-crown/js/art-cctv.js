/* Velvet Crown: camera 04 still and the gala photographer's contact sheet. */
(function () {
  'use strict';
  var Art = window.Art;
  var MONO = 'font-family="Courier New,monospace"';

  Art.cctv = function () {
    var s = '<svg class="cctv" viewBox="0 0 800 500" role="img" aria-label="Camera 04 still at 23:11:34: a masked figure in a tuxedo holds a keycard to the Crown Office door">';
    s += '<rect width="800" height="500" fill="#18211d"/>';
    s += '<path d="M0 500H800L560 360H240z" fill="#2a3530"/><path d="M0 0 240 60V360L0 500z" fill="#202a26"/><path d="M800 0 560 60V360L800 500z" fill="#243029"/>';
    s += '<rect x="240" y="60" width="320" height="300" fill="#2e3a35"/>';
    for (var i = -4; i <= 4; i++) s += '<path d="M' + (400 + i * 60) + ' 360L' + (400 + i * 210) + ' 500" stroke="#1d2622" stroke-width="2"/>';
    s += '<path d="M150 420H650M80 460H720" stroke="#1d2622" stroke-width="2"/>';
    /* Door, plaque, card reader */
    s += '<rect x="330" y="110" width="140" height="250" fill="#171e1b" stroke="#5b6a62" stroke-width="4"/>';
    s += '<rect x="346" y="126" width="108" height="100" fill="none" stroke="#3c4842" stroke-width="2"/><rect x="346" y="240" width="108" height="100" fill="none" stroke="#3c4842" stroke-width="2"/>';
    s += '<circle cx="452" cy="244" r="5" fill="#8a9690"/><rect x="372" y="88" width="56" height="13" fill="#6f6a4f"/>';
    s += '<rect x="304" y="222" width="14" height="24" rx="2" fill="#0f1412" stroke="#6b7a72"/><circle cx="311" cy="228" r="2.6" fill="#ff3b3b"/>';
    /* Height strip on the door frame: 1 m = 119 px, floor at y 360 */
    s += '<rect x="474" y="110" width="9" height="250" fill="#d8d2b8" opacity=".85"/>';
    for (var h = 10; h <= 21; h++) {
      var y = (360 - h / 10 * 119).toFixed(1), major = h >= 16 && h <= 20;
      s += '<path d="M474 ' + y + 'H' + (major ? 486 : 481) + '" stroke="#1b1411" stroke-width="1.4"/>';
      if (major) s += '<text x="489" y="' + (+y + 4) + '" ' + MONO + ' font-size="11" fill="#e0dccb">' + (h / 10).toFixed(2) + '</text>';
    }
    /* The figure, seen from behind */
    s += '<g fill="#0a0c0d">';
    s += '<path d="M384 262 380 358H398L402 270H408L412 358H430L426 262z" fill="#060708"/>';
    s += '<path d="M370 186C372 180 384 176 404 176 424 176 436 180 438 186L436 270H372z"/>';
    s += '<path d="M376 262 380 298 398 282H410L428 298 432 262z"/>';
    s += '<rect x="398" y="170" width="12" height="10"/><ellipse cx="404" cy="158" rx="15" ry="17" fill="#060708"/>';
    s += '<path d="M374 190C360 200 340 214 322 228L318 238C338 226 358 214 378 206z"/>';
    s += '<path d="M436 190C442 214 442 240 438 262H430C432 240 432 214 430 196z"/></g>';
    s += '<path d="M416 150C425 154 425 166 416 173 420 164 420 157 416 150z" fill="#e8ece6"/>';
    s += '<path d="M392 156C384 162 382 172 386 180" stroke="#141719" stroke-width="3" fill="none"/>';
    s += '<circle cx="318" cy="233" r="7" fill="#040505"/><rect x="306" y="225" width="12" height="17" fill="#f1f2ec" transform="rotate(-10 312 233)"/>';
    /* Police annotation */
    s += '<path d="M404 142H474" stroke="#f2c230" stroke-width="1.5" stroke-dasharray="4 3"/><path d="M488 142H582" stroke="#f2c230" stroke-dasharray="2 3"/>';
    s += '<rect x="582" y="128" width="158" height="27" fill="#000" opacity=".6"/><text x="592" y="147" ' + MONO + ' font-size="15" fill="#f2c230">1.83 m \u00b1 0.02</text>';
    /* Video texture and overlays */
    s += '<rect width="800" height="500" fill="url(#p-scan)"/><rect width="800" height="500" filter="url(#f-grain)" opacity=".22"/>';
    s += '<rect width="800" height="500" fill="url(#g-vignette)"/>';
    s += '<text x="18" y="30" ' + MONO + ' font-size="17" fill="#d9e4dc">CAM 04  STAIRCASE LANDING</text>';
    s += '<text x="782" y="30" text-anchor="end" ' + MONO + ' font-size="17" fill="#d9e4dc">14/11  23:11:34</text>';
    s += '<circle cx="24" cy="478" r="6" fill="#ff3b3b"/><text x="36" y="483" ' + MONO + ' font-size="14" fill="#d9e4dc">REC</text>';
    s += '</svg>';
    return s;
  };

  function singer(x, y, sc, gown, hair) {
    var t = 'translate(' + x + ' ' + y + ') scale(' + sc + ')';
    var hairPath = hair === 'long' ? '<path d="M-15 -8C-18-30 18-30 15-8 18 8 20 22 24 32 10 28 12 12 10 2L-10 2C-12 12-10 28-24 32-20 22-18 8-15-8z" fill="#0a0a0b"/>'
      : '<path d="M-16 4C-20-26 20-26 16 4 14 8 10 8 10 2L-10 2C-10 8-14 8-16 4z" fill="#0a0a0b"/>';
    return '<g transform="' + t + '"><circle r="13" fill="#6a6a6c"/>' + hairPath +
      '<path d="M-7-2C-3-5 3-5 7-2" stroke="#e6e6e6" stroke-width="3" fill="none"/>' +
      '<path d="M-10 14C-22 50-30 100-42 140H42C30 100 22 50 10 14z" fill="' + gown + '"/>' +
      '<path d="M-10 22-26 60M10 22 20 40 8 44" stroke="#6a6a6c" stroke-width="5" fill="none" stroke-linecap="round"/></g>';
  }
  function scene(kind) {
    var s = '<rect width="390" height="220" fill="#1d1d1f"/>';
    if (kind === 'duet' || kind === 'bow') {
      s += '<rect width="390" height="220" fill="#29292b"/>';
      for (var f = 10; f < 390; f += 22) s += '<path d="M' + f + ' 0V160" stroke="#222224" stroke-width="6"/>';
      s += '<rect y="160" width="390" height="60" fill="#3d3d3f"/>';
      s += '<path d="M120 0 55 220H185zM270 0 205 220H335z" fill="#fff" opacity=".1"/>';
      if (kind === 'duet') {
        s += singer(120, 64, 1, '#8e8e90', 'long') + singer(270, 64, 1, '#0c0c0d', 'bob');
        s += '<path d="M168 80V210M222 80V210" stroke="#bdbdbd" stroke-width="2"/><circle cx="168" cy="78" r="5" fill="#bdbdbd"/><circle cx="222" cy="78" r="5" fill="#bdbdbd"/>';
      } else {
        s += '<g transform="rotate(28 150 200)">' + singer(150, 90, .95, '#8e8e90', 'long') + '</g><g transform="rotate(28 250 200)">' + singer(250, 90, .95, '#0c0c0d', 'bob') + '</g>';
        s += '<path d="M0 0H70C60 60 64 150 40 220H0zM390 0H320C330 60 326 150 350 220H390z" fill="#141415"/>';
      }
    } else if (kind === 'front') {
      s += '<rect x="80" y="20" width="230" height="110" fill="#2a2a2c"/><rect x="80" y="112" width="230" height="18" fill="#3d3d3f"/>';
      s += '<path d="M150 20 120 130H180zM240 20 210 130H270z" fill="#fff" opacity=".1"/>';
      s += singer(150, 58, .42, '#8e8e90', 'long') + singer(240, 58, .42, '#0c0c0d', 'bob');
      for (var hx = 30; hx <= 370; hx += 58) {
        s += '<ellipse cx="' + hx + '" cy="222" rx="30" ry="26" fill="#0f0f10"/><circle cx="' + hx + '" cy="178" r="21" fill="#141415"/>';
      }
      s += '<path d="M198 168C202 162 208 162 212 168" stroke="#bdbdbd" stroke-width="2" fill="none"/><path d="M200 196 204 190 208 194 212 188 216 196z" fill="#d6d6d6"/>';
      s += '<ellipse cx="205" cy="182" rx="40" ry="38" fill="none" stroke="#ff4a3a" stroke-width="3"/>';
    } else {
      s += '<rect width="390" height="220" fill="#232325"/><circle cx="195" cy="100" r="120" fill="#fff" opacity=".06"/>';
      s += '<ellipse cx="160" cy="112" rx="38" ry="46" fill="#5d5d5f"/><path d="M122 100C118 50 190 40 196 90L190 120C170 90 140 90 122 100z" fill="#0a0a0b"/>';
      s += '<path d="M150 96C160 84 182 84 190 96 182 106 160 106 150 96z" fill="#d8d8d8"/>';
      s += '<ellipse cx="236" cy="112" rx="36" ry="44" fill="#4d4d4f"/><path d="M270 120C280 60 214 50 204 96L210 124C226 100 256 98 270 120z" fill="#0a0a0b"/>';
      s += '<path d="M206 96C214 86 232 86 242 96 232 106 214 106 206 96z" fill="#0c0c0d" stroke="#bbbbbb"/><path d="M244 88 262 40M250 92 276 52" stroke="#9a9a9a" stroke-width="3"/>';
      s += '<rect y="170" width="390" height="50" fill="#141415"/>';
    }
    return s;
  }

  Art.contactSheet = function () {
    var frames = [
      { x: 40, y: 60, t: '23:03:12', n: '14', k: 'duet', note: 'Duet: I.V. + C.M.' },
      { x: 470, y: 60, t: '23:14:47', n: '15', k: 'front', note: 'Mr V., front row' },
      { x: 40, y: 360, t: '23:18:05', n: '16', k: 'kiss', note: 'the cheek kiss' },
      { x: 470, y: 360, t: '23:24:40', n: '17', k: 'bow', note: 'finale, bows' }
    ];
    var s = '<svg class="contact" viewBox="0 0 900 640" role="img" aria-label="Contact sheet: four photographs of the duet, timestamped 23:03, 23:14, 23:18 and 23:24">';
    s += '<defs><clipPath id="cs-clip"><rect width="390" height="220"/></clipPath></defs><rect width="900" height="640" fill="#161415"/>';
    [30, 330].forEach(function (y) {
      s += '<rect x="20" y="' + y + '" width="860" height="270" fill="#050505"/>';
      for (var i = 0; i < 34; i++) {
        s += '<rect x="' + (30 + i * 25) + '" y="' + (y + 8) + '" width="13" height="9" rx="2" fill="#2d2a2b"/>' +
          '<rect x="' + (30 + i * 25) + '" y="' + (y + 253) + '" width="13" height="9" rx="2" fill="#2d2a2b"/>';
      }
      s += '<text x="760" y="' + (y + 25) + '" font-family="Arial" font-size="11" fill="#6e6a60">VELVET 400</text>';
    });
    frames.forEach(function (f) {
      s += '<g transform="translate(' + f.x + ' ' + f.y + ')"><g clip-path="url(#cs-clip)">' + scene(f.k) + '</g>' +
        '<text x="378" y="210" text-anchor="end" ' + MONO + ' font-weight="700" font-size="19" fill="#ff9a3c">' + f.t + '</text>' +
        '<text x="12" y="30" font-family="Caveat,cursive" font-size="26" fill="#ff4a3a">' + f.note + '</text></g>';
      s += '<text x="' + (f.x + 2) + '" y="' + (f.y + 236) + '" font-family="Arial" font-size="11" fill="#77726a">\u25b8 ' + f.n + '</text>';
    });
    s += '</svg>';
    return s;
  };
})();

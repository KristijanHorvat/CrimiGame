/* Velvet Crown: Envelope B, Victor's safe. */
(function () {
  'use strict';
  var C = window.CASE, Art = window.Art;

  /* Page 13, written in Victor's card shorthand. */
  C.cipher = '7S 8H 5H 3D 7H 5S 5H QS JD 7H 8H 4C 2S 6S 7S 6S 7D 3H 8H 9H QH 4H AD 9H 6S 9D 8S AS JC 4H 5H 5S 5D KH QS KD 5S 2S 2S 6H 2C'.split(' ');

  C.add({ id: 'B1', env: 'B', kind: 'safe', title: 'Safe inventory', blurb: 'What Victor kept behind the painting.',
    render: function () {
      return '<article class="doc doc-report">' + C.head('Monte Verde Criminal Police', 'Case 1114') +
        '<h3 class="rep-title">Contents of the wall safe</h3>' +
        '<p>Opened at 03:40 with the code found by the detectives, in the presence of Mrs Valmont.</p><ol class="items">' +
        '<li>\u20ac220,000 in used notes, the casino\u2019s float. Bank bands intact.</li>' +
        '<li>Deeds to the Velvet Crown Casino, dated 14 November 1981.</li>' +
        '<li>Mr Valmont\u2019s black leather notebook, pages 1 to 15 used.</li>' +
        '<li>Tucked inside the notebook: a worn playing card with handwriting on the back.</li>' +
        '<li>A handwritten draft of a new will, with a letter from the notary.</li>' +
        '<li>A witness summons from the Tribunal of Monte Verde: <i>State v. A. G.</i>, hearing of 9 March 2004. Witness for the prosecution: Victor Valmont.</li>' +
        '<li>A framed four-leaf clover.</li></ol>' +
        '<p>Mrs Valmont had never seen inside the safe. Nothing appears to be missing.</p></article>';
    } });

  C.add({ id: 'B2', env: 'B', kind: 'will', title: 'The draft will', blurb: 'Unsigned. The notary was booked for Monday.',
    render: function () {
      return '<article class="doc doc-will"><div class="notary">' +
        '<p class="notary-head">Ma\u00eetre Hugo Lenoir, Notary<span>12 Rue des Palmiers, Monte Verde</span></p>' +
        '<p class="doc-date">Tuesday 10 November</p><p>Dear Mr Valmont,</p>' +
        '<p>As requested, I have reserved Monday 16 November at 10:00 for the signing of your new will. Until it is signed, your will of 2017 remains valid, under which Mrs Isabella Valmont is your sole heir.</p>' +
        '<p>As you asked, all correspondence on this matter goes to the casino and not to your home. Please bring the full name and particulars of the new principal beneficiary, which you preferred not to put in writing.</p>' +
        '<p>Yours faithfully,<br>H. Lenoir</p></div>' +
        '<div class="draft"><p class="draft-title">My last will. Draft, for Lenoir on Monday.</p>' +
        '<p>1. To my wife Isabella: the villa at Cap Rouge and twenty thousand a month for life.</p>' +
        '<p>2. To Marco Santoro: nothing. He knows why.</p>' +
        '<p>3. The Velvet Crown, entire, to the only child of the man I wronged in March 2004. Restitution: too late, but in full.</p>' +
        '<p class="draft-sig">V. V.</p></div><p class="caption">The draft is not signed.</p></article>';
    } });

  C.add({ id: 'B3', env: 'B', kind: 'notebook', title: 'Victor\u2019s black notebook', blurb: 'His private notes. Page 13 is in code.',
    render: function () {
      var cells = C.cipher.map(function (t, i) {
        var r = t.slice(0, -1), s = t.slice(-1);
        return '<label class="cell">' + Art.mini(r, s) +
          '<input type="text" maxlength="1" data-i="' + i + '" autocomplete="off" autocapitalize="characters" spellcheck="false" aria-label="Letter for card ' + (i + 1) + '"></label>';
      }).join('');
      return '<article class="doc doc-notebook"><div class="nb-spread">' +
        '<section class="nb-page"><p class="nb-no">11</p><p>3 Nov. Count short again, the third time since September. Forty thousand. Only Marco touches the money between the tables and the Cage. Deal with it after the gala.</p></section>' +
        '<section class="nb-page"><p class="nb-no">12</p><p>7 Nov. Leopold owes 380,000 now. Told him: pay by Monday, or I go to the medical board about the prescriptions he writes for himself.</p>' +
        '<p>9 Nov. Petrov: sixty million, third offer. Over my dead body. And I. and N. at the Aurora on Thursday. I\u2019m old, not blind.</p>' +
        '<p>Celeste wants to run to Petrov. The contract says three more years. I\u2019ll hold her to every day of it.</p></section>' +
        '<section class="nb-page nb-cipher"><p class="nb-no">13</p>' +
        '<p class="nb-help">Victor wrote this page in cards. Type a letter under each card as you work it out. Your letters are saved.</p>' +
        '<div class="cipher" data-cipher>' + cells + '</div>' +
        '<p class="nb-help"><button type="button" class="btn btn-small" data-cipher-clear>Clear my letters</button></p></section>' +
        '<section class="nb-page"><p class="nb-no">14</p><p>Same hands. Same smile. Even the same trick with the ring. After twenty-two years I\u2019d know it anywhere.</p></section>' +
        '<section class="nb-page"><p class="nb-no">15</p><p>Monday: Lenoir. Then the whole truth about March 2004. Those marked cards were never his. I let an innocent man die in a cell to protect the name of this house.</p>' +
        '<p>The Last Hand was always going to come for me.</p></section></div></article>';
    } });

  C.add({ id: 'B4', env: 'B', kind: 'card', title: 'The dealer\u2019s shorthand', blurb: 'A worn card tucked into the notebook.',
    render: function () {
      return '<article class="doc doc-shorthand"><div class="oldcard"><div class="oldcard-writing">' +
        '<p class="sh-title">Dealer\u2019s shorthand</p><p class="sh-sub">for what the house must never read</p>' +
        '<p>' + Art.suit('H') + ' carries the first thirteen.</p>' +
        '<p>' + Art.suit('S') + ' carries the last thirteen.</p>' +
        '<p>' + Art.suit('D') + ' is a breath between words.</p>' +
        '<p>' + Art.suit('C') + ' are liars. Pay them no mind.</p></div></div>' +
        '<p class="caption">Found between pages 12 and 13, written on the back of a card from a very old casino deck.</p></article>';
    } });

  C.add({ id: 'B5', env: 'B', kind: 'log', title: 'Office keycard log', blurb: 'Every unlock of the Crown Office door.',
    render: function () {
      var rows = [['19:48:10', 'V. VALMONT'], ['21:12:44', 'V. VALMONT'], ['22:01:05', 'M. SANTORO'], ['23:11:31', 'I. VALMONT'], ['23:29:18', 'V. VALMONT'], ['00:04:52', 'M. SANTORO']];
      return '<article class="doc doc-log">' + C.head('Velvet Crown security', 'Door controller printout') +
        '<h3 class="rep-title">Crown Office door: unlock events</h3><p class="log-sub">Saturday 14 November to Sunday 15 November</p>' +
        '<table class="ledger ledger-mono"><thead><tr><th>Time</th><th>Keycard</th></tr></thead><tbody>' +
        rows.map(function (r) { return '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>'; }).join('') + '</tbody></table>' +
        '<h4>How the lock works</h4><p>Only unlocks are recorded. The door locks itself when it closes, and leaving the office is not logged.</p>' +
        '<p>Four cards open this door: Victor Valmont\u2019s, Isabella Valmont\u2019s, Marco Santoro\u2019s, and a master card kept in the security office safe. The master card was not used tonight.</p></article>';
    } });

  C.add({ id: 'B6', env: 'B', kind: 'cctv', title: 'Camera 04 still', blurb: 'The landing outside the office at 23:11.',
    render: function () {
      return '<article class="doc doc-cctv"><div class="cctv-frame">' + Art.cctv() + '</div>' +
        '<div class="tech-notes"><h4>Technician\u2019s notes, camera 04</h4><table class="ledger"><tbody>' +
        '<tr><td>19:48, 21:12</td><td>V. Valmont, alone.</td></tr>' +
        '<tr><td>22:01</td><td>M. Santoro, carrying a small box. Leaves at 22:02.</td></tr>' +
        '<tr><td>23:11:29</td><td>Unidentified person comes up the stairs. Enters 23:11:31, leaves 23:14:02.</td></tr>' +
        '<tr><td>23:29</td><td>V. Valmont, alone.</td></tr><tr><td>00:04</td><td>M. Santoro, with the cash bag.</td></tr></tbody></table>' +
        '<p>Measured against the height strip on the door frame, the 23:11 visitor stands 1.83 m, give or take 2 cm, including footwear. Black tuxedo, black gloves, white full-face Bauta mask. The card is held to the reader in the <strong>left</strong> hand. Nothing visible is carried in or out.</p>' +
        '<p>About sixty white Bauta masks were handed out at the entrance to guests who arrived without one. Staff wore black half-masks.</p></div></article>';
    } });

  C.add({ id: 'B7', env: 'B', kind: 'film', title: 'Photographer\u2019s contact sheet', blurb: 'The surprise duet, frame by frame.',
    render: function () {
      return '<article class="doc doc-film"><div class="film-frame">' + Art.contactSheet() + '</div>' +
        '<p class="caption">R\u00e9my Laurent, official gala photographer. His camera clock was checked against the casino\u2019s master clock at 20:00 and was correct to the second. The grease-pencil notes are his.</p></article>';
    } });
})();

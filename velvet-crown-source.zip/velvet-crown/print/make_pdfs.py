"""Render the printable case file to A4 PDFs with headless Chromium (Playwright)."""
import asyncio, os
from playwright.async_api import async_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'dist', 'print')
SETS = [('A', '1-Envelope-A.pdf', 'Envelope A'), ('B', '2-Envelope-B-sealed.pdf', 'Envelope B'),
        ('C', '3-Envelope-C-sealed.pdf', 'Envelope C'), ('W', '0-Detective-worksheets.pdf', 'Worksheets')]
FOOT = ('<div style="width:100%;font-family:Georgia,serif;font-size:7pt;color:#8a7f70;padding:0 15mm;'
        'display:flex;justify-content:space-between;"><span>Monte Verde Criminal Police &middot; Case 1114 &middot; {label}</span>'
        '<span>Page <span class="pageNumber"></span> of <span class="totalPages"></span></span></div>')

async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        for key, name, label in SETS:
            await page.goto('file://' + os.path.join(HERE, 'print.html') + '?set=' + key)
            await page.wait_for_selector('body[data-ready]', state='attached', timeout=20000)
            await page.pdf(path=os.path.join(OUT, name), format='A4', print_background=True, display_header_footer=True,
                           header_template='<span></span>', footer_template=FOOT.format(label=label),
                           margin={'top': '14mm', 'bottom': '16mm', 'left': '15mm', 'right': '15mm'})
            print('wrote', name)
        await browser.close()
        print('errors:', errors or 'none')

asyncio.run(main())

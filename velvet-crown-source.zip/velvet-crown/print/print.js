/* Velvet Crown: builds the paper case file. print.html?set=A | B | C | W */
(function () {
  'use strict';
  var C = window.CASE, Art = window.Art;
  var SET = (new URLSearchParams(location.search).get('set') || 'A').toUpperCase();
  var root = document.getElementById('print');

  var ev = function (id) { return C.evidence.filter(function (e) { return e.id === id; })[0]; };
  var inEnv = function (env) { return C.evidence.filter(function (e) { return e.env === env; }); };
  function tag(id) { return '<div class="tag"><span class="tag-hole"></span><span><b>' + id + '</b>' + ev(id).title + '</span></div>'; }
  function page(html, cls) { return '<section class="pdoc ' + (cls || '') + '">' + html + '</section>'; }
  function docPage(id) { var e = ev(id); return page(tag(id) + e.render({ names: ['', ''] }), 'pdoc-' + e.kind); }

  var COVER = {
    A: ['The night of the masquerade', 'Open this envelope first.'],
    B: ['Victor\u2019s safe', 'Keep this envelope sealed. Open it only when you have cracked Victor\u2019s safe in the game.'],
    C: ['Lab results and lockers', 'Keep this envelope sealed. Open it only when Chief Inspector Duret has answered your call in the game.']
  };
  function cover(env) {
    var items = inEnv(env), c = COVER[env];
    var list = env === 'A'
      ? '<ul class="cv-list">' + items.map(function (e) { return '<li><span class="box"></span><b>' + e.id + '</b>' + e.title + '</li>'; }).join('') + '</ul>'
      : '<p class="cv-count">' + items.length + ' documents inside, ' + items[0].id + ' to ' + items[items.length - 1].id + '</p>';
    return page('<div class="cover-label"><p class="cv-org">Monte Verde Criminal Police<br>Case 1114</p>' +
      '<div class="cv-seal">' + env + '</div><h1>Envelope ' + env + '</h1><p class="cv-title">' + c[0] + '</p>' +
      '<p class="cv-rule">' + c[1] + '</p>' + list + '</div>' +
      (env === 'A' ? '<p class="cv-print">Cut out the label along the dashed line and stick it on an envelope, or keep this sheet on top of the pile.</p>'
        : '<p class="cv-print">For whoever prints this: don\u2019t read the pages that follow. Slide them straight into an envelope with this sheet on top, and seal it.</p>'), 'cover');
  }

  function howto() {
    return page('<div class="howto"><h2 class="p-title">How to work this case</h2>' +
      '<p>You are two detectives, and this is your case file. The game on your laptop or phone is headquarters: it guards the locked evidence, holds the hints, and hears your final accusation.</p>' +
      '<p>Write on everything. Circle times, underline anything that sounds like a lie, cross out suspects, scribble in the margins. Nothing here is precious.</p>' +
      '<h3>The envelopes</h3><ul>' +
      '<li><strong>Envelope A</strong> is yours now.</li>' +
      '<li><strong>Envelope B</strong> stays sealed until you crack Victor\u2019s safe in the game.</li>' +
      '<li><strong>Envelope C</strong> stays sealed until you decode Victor\u2019s notebook and Chief Inspector Duret answers your call.</li></ul>' +
      '<h3>Good to know</h3><ul>' +
      '<li>Everything in the envelopes is also in the game, so you can zoom in on screen whenever the paper is too small.</li>' +
      '<li>A magnifying glass makes the crime scene photograph more fun. Your phone camera\u2019s zoom works too.</li>' +
      '<li>Stuck? The game has three hints for each lock, from gentle to generous.</li>' +
      '<li>When you are both sure, fill in the accusation form together, then enter it in the game to hear the verdict. You only get one.</li></ul></div>', 'pdoc-howto');
  }

  function letter() {
    var h = ev('A1').render({ names: ['@@1', '@@2'] }).replace('@@1', '<span class="blank"></span>').replace('@@2', '<span class="blank"></span>');
    return page(tag('A1') + h, 'pdoc-letter');
  }

  function photo() {
    return page('<div class="rot-box"><div class="rot-inner"><div class="rot-head">' + tag('A3') +
      '<p class="rot-cap">Photograph 3: Victor Valmont\u2019s desk in the Crown Office, taken at 00:41 by the scene officer. The numbered markers match the scene report.</p></div>' +
      '<div class="photo-print">' + Art.deskScene() + '</div></div></div>', 'pdoc-rot');
  }

  function dossiers() {
    return page(tag('A4') + '<h2 class="p-title">The six suspects</h2><p class="p-sub">Police files. Heights were measured in the shoes each person wore to the gala.</p>' +
      C.suspects.map(function (s) {
        return '<div class="sc"><div class="sc-portrait">' + Art.portrait(s.id) + '</div><div class="sc-body"><h3>' + s.name + '</h3>' +
          '<p class="sc-role">' + s.role + ', ' + s.age + '</p><table class="sc-kv"><tr><th>Height</th><td>' + s.height + '</td></tr>' +
          '<tr><th>Mask tonight</th><td>' + s.mask + '</td></tr><tr><th>Office keycard</th><td>' + s.keycard + '</td></tr></table>' +
          '<p class="sc-about">' + s.about + '</p><p class="sc-checks"><span class="box"></span>Suspicious<span class="box"></span>Cleared</p></div></div>';
      }).join(''), 'pdoc-dossier');
  }

  function shorthand() {
    var e = ev('B4'), tmp = document.createElement('div');
    tmp.innerHTML = e.render();
    var back = '<svg viewBox="0 0 252 352" preserveAspectRatio="none" aria-hidden="true"><rect width="252" height="352" fill="#f4efe3"/>' +
      '<rect x="12" y="12" width="228" height="328" rx="10" fill="url(#p-cardback)" stroke="#c9a227" stroke-width="2"/>' +
      '<ellipse cx="126" cy="176" rx="48" ry="40" fill="#5a0d1f" stroke="#c9a227" stroke-width="2"/>' +
      '<use href="#crown" x="100" y="158" width="52" height="39" fill="#c9a227"/></svg>';
    return page(tag('B4') + '<h2 class="p-title">' + e.title + '</h2><p class="p-sub">' + tmp.querySelector('.caption').textContent + '</p>' +
      '<div class="card-pair"><div class="pcard pcard-writing">' + tmp.querySelector('.oldcard-writing').outerHTML + '</div>' +
      '<div class="pcard pcard-back">' + back + '</div></div>' +
      '<p class="cut-note">Cut out both sides along the dashed lines and glue them back to back to hold the real thing.</p>', 'pdoc-card');
  }

  function caseBoard() {
    return page('<h2 class="p-title">Case board</h2><p class="p-sub">One row per suspect. Fill it in as you go, and change your minds as often as you like.</p>' +
      '<table class="ws-table ws-board"><thead><tr><th class="ws-sus">Suspect</th><th>Motive</th><th>Alibi</th><th>Opportunity</th><th class="ws-v">Verdict</th></tr></thead><tbody>' +
      C.suspects.map(function (s) {
        return '<tr><td class="ws-sus">' + Art.portrait(s.id, 'portrait ws-portrait') + '<span>' + s.name + '</span></td><td></td><td></td><td></td><td class="ws-v"></td></tr>';
      }).join('') + '</tbody></table>', 'pdoc-ws');
  }
  function timeline() {
    var rows = '';
    for (var m = 20 * 60 + 30; m <= 24 * 60 + 30; m += 15) {
      rows += '<tr><th>' + String(Math.floor(m / 60) % 24).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0') + '</th><td></td><td class="ws-src"></td></tr>';
    }
    return page('<h2 class="p-title">Timeline of the night</h2><p class="p-sub">Who was where, and when. Note which document told you.</p>' +
      '<table class="ws-table ws-time"><thead><tr><th>Time</th><th>What happened</th><th class="ws-src">Source</th></tr></thead><tbody>' + rows + '</tbody></table>', 'pdoc-ws');
  }
  function accusationForm() {
    var qs = ['Who killed Victor Valmont?', 'How did the poison reach him?', 'How did the killer get into the office?', 'Why?'];
    return page('<header class="letterhead"><svg class="lh-crest" viewBox="0 0 100 110" aria-hidden="true"><use href="#crest"/></svg>' +
      '<div><p class="lh-org">Monte Verde Criminal Police</p><p class="lh-sub">Case 1114: formal accusation</p></div></header>' +
      qs.map(function (q, i) { return '<div class="acc-q"><p><strong>' + (i + 1) + '.</strong> ' + q + '</p><div class="lines"></div></div>'; }).join('') +
      '<div class="acc-sign"><div><span class="sigline"></span><p>Detective</p></div><div><span class="sigline"></span><p>Detective</p></div></div>' +
      '<p class="acc-foot">Enter your answers in the game to hear Chief Inspector Duret\u2019s verdict. You only get one accusation.</p>', 'pdoc-acc');
  }

  var SETS = {
    A: function () { return cover('A') + howto() + letter() + docPage('A2') + photo() + dossiers() + docPage('A5') + docPage('A6') + docPage('A7'); },
    B: function () { return cover('B') + ['B1', 'B2', 'B3'].map(function (id) { return docPage(id); }).join('') + shorthand() + ['B5', 'B6', 'B7'].map(function (id) { return docPage(id); }).join(''); },
    C: function () { return cover('C') + ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7'].map(function (id) { return docPage(id); }).join(''); },
    W: function () { return caseBoard() + timeline() + accusationForm(); }
  };
  root.innerHTML = SETS[SET]();

  /* Paper versions of the few interactive bits */
  Array.prototype.forEach.call(root.querySelectorAll('[data-cipher] input'), function (inp) {
    var s = document.createElement('span'); s.className = 'wbox'; inp.parentNode.replaceChild(s, inp);
  });
  var help = root.querySelectorAll('.nb-help');
  if (help[0]) help[0].textContent = 'Victor wrote this page in cards. Write a letter under each card as you work it out.';
  if (help[1]) help[1].parentNode.removeChild(help[1]);
  Array.prototype.forEach.call(root.querySelectorAll('.jump, button'), function (n) { n.parentNode.removeChild(n); });

  document.title = 'Death at the Velvet Crown: ' + (SET === 'W' ? 'detective worksheets' : 'envelope ' + SET);
  document.fonts.ready.then(function () { setTimeout(function () { document.body.setAttribute('data-ready', '1'); }, 150); });
})();
